(function() {
	'use strict';

	function getCsrf() {
		const tokenMeta = document.querySelector('meta[name="_csrf"]');
		const headerMeta = document.querySelector('meta[name="_csrf_header"]');

		return {
			token: tokenMeta ? tokenMeta.getAttribute('content') : null,
			header: headerMeta ? headerMeta.getAttribute('content') : null
		};
	}

	async function postJson(url, bodyObj) {
		const csrf = getCsrf();
		const headers = { 'Content-Type': 'application/json' };

		if (csrf.token && csrf.header) {
			headers[csrf.header] = csrf.token;
		}

		const res = await fetch(url, {
			method: 'POST',
			headers,
			body: JSON.stringify(bodyObj || {})
		});

		const text = await res.text();
		let json = null;

		try {
			json = JSON.parse(text);
		} catch (e) {
			// ignore
		}

		if (!res.ok) {
			const msg = (json && json.message) ? json.message : (text || ('HTTP ' + res.status));
			throw new Error(msg);
		}

		return json || { message: text };
	}

	async function getJson(url) {
		const res = await fetch(url, {
			method: 'GET',
			headers: { 'Accept': 'application/json' }
		});

		const text = await res.text();
		let json = null;

		try {
			json = JSON.parse(text);
		} catch (e) {
			// ignore
		}

		if (!res.ok) {
			const msg = (json && json.message) ? json.message : (text || ('HTTP ' + res.status));
			throw new Error(msg);
		}

		return json || { message: text };
	}

	async function deleteJson(url) {
		const csrf = getCsrf();
		const headers = { 'Accept': 'application/json' };

		if (csrf.token && csrf.header) {
			headers[csrf.header] = csrf.token;
		}

		const res = await fetch(url, {
			method: 'DELETE',
			headers
		});

		const text = await res.text();
		let json = null;

		try {
			json = JSON.parse(text);
		} catch (e) {
			// ignore
		}

		if (!res.ok) {
			const msg = (json && json.message) ? json.message : (text || ('HTTP ' + res.status));
			throw new Error(msg);
		}

		return json || { message: text };
	}

	async function postFormData(url, formData) {
		const csrf = getCsrf();
		const headers = {};

		if (csrf.token && csrf.header) {
			headers[csrf.header] = csrf.token;
		}

		const res = await fetch(url, {
			method: 'POST',
			headers,
			body: formData
		});

		const text = await res.text();
		let json = null;

		try {
			json = JSON.parse(text);
		} catch (e) {
			// ignore
		}

		if (!res.ok) {
			const msg = (json && json.message) ? json.message : (text || ('HTTP ' + res.status));
			throw new Error(msg);
		}

		return json || { message: text };
	}

	function nvl(value) {
		return value == null ? '' : String(value);
	}

	function trimValue(value) {
		return nvl(value).trim();
	}

	function normalizeBusinessNumber(value) {
		return nvl(value).replace(/\D/g, '').slice(0, 10);
	}

	function isNonNegativeIntegerString(value) {
		const v = trimValue(value);
		return /^[0-9]+$/.test(v);
	}

	function isLikelyImageUrl(url) {
		const u = trimValue(url).toLowerCase().split('?')[0].split('#')[0];
		return u.endsWith('.png') || u.endsWith('.jpg') || u.endsWith('.jpeg') || u.endsWith('.gif') || u.endsWith('.webp');
	}

	function isLikelyPdfUrl(url) {
		const u = trimValue(url).toLowerCase().split('?')[0].split('#')[0];
		return u.endsWith('.pdf');
	}

	function isImageFile(file) {
		return !!file && !!file.type && file.type.startsWith('image/');
	}

	function isPdfFile(file) {
		return !!file && file.type === 'application/pdf';
	}

	function joinAddressText(parts) {
		return parts
			.map(function(part) { return trimValue(part); })
			.filter(function(part) { return part.length > 0; })
			.join(' ');
	}

	function getPostcodeConstructor() {
		if (window.daum && window.daum.Postcode) {
			return window.daum.Postcode;
		}

		if (window.kakao && window.kakao.Postcode) {
			return window.kakao.Postcode;
		}

		return null;
	}

	function endsWithAny(value, suffixes) {
		const normalized = trimValue(value);
		return suffixes.some(function(suffix) {
			return normalized.endsWith(suffix);
		});
	}

	/**
	 * 관리자 화면의 주소 API 결과를 회원가입/회원정보 화면과 같은 규칙으로 1차 정규화합니다.
	 * 최종 저장값은 서버의 AddressRegionResolver가 행정구역 DB 기준으로 다시 확정합니다.
	 */
	function resolvePostcodeRegion(data) {
		if (window.HiddenAutoAddressRegion &&
			typeof window.HiddenAutoAddressRegion.fromDaum === 'function') {
			return window.HiddenAutoAddressRegion.fromDaum(data || {});
		}

		data = data || {};

		const selectedAddress =
			trimValue(data.roadAddress) ||
			trimValue(data.address) ||
			trimValue(data.jibunAddress);
		const province = trimValue(data.sido);
		const tokens = [];

		trimValue(data.sigungu).split(/\s+/).filter(Boolean).forEach(function(token) {
			if (!tokens.includes(token)) {
				tokens.push(token);
			}
		});
		selectedAddress.split(/\s+/).filter(Boolean).forEach(function(token) {
			if (token !== province && !tokens.includes(token)) {
				tokens.push(token);
			}
		});

		const provinceIsDo = province.endsWith('도');
		let siName = '';
		let guName = '';

		if (provinceIsDo) {
			siName = tokens.find(function(token) {
				return endsWithAny(token, ['시', '군']);
			}) || '';
			guName = tokens.find(function(token) {
				return token.endsWith('구');
			}) || '';
		} else {
			guName = tokens.find(function(token) {
				return endsWithAny(token, ['구', '군']);
			}) || '';
		}

		return {
			zipCode: trimValue(data.zonecode),
			doName: province,
			siName: siName,
			guName: guName,
			roadAddress: selectedAddress
		};
	}

	/* =========================
	   1) 비밀번호 초기화 / 접속금지
	========================= */
	document.querySelectorAll('.js-reset-password').forEach(function(el) {
		el.addEventListener('click', async function() {
			const memberId = el.getAttribute('data-member-id');
			const username = el.getAttribute('data-username') || '';

			if (!memberId) {
				return;
			}

			const ok = confirm('해당 유저의 비밀번호를 초기화 하시겠습니까?');
			if (!ok) {
				return;
			}

			try {
				await postJson('/management/member/' + memberId + '/resetPassword', {});
				alert('비밀번호가 초기화되었고, 해당 휴대폰번호로 안내 문자가 발송되었습니다.\n(아이디: ' + username + ')');
			} catch (e) {
				alert('실패: ' + (e && e.message ? e.message : e));
			}
		});
	});

	document.querySelectorAll('.js-disable-member').forEach(function(el) {
		el.addEventListener('click', async function() {
			const memberId = el.getAttribute('data-member-id');
			const username = el.getAttribute('data-username') || '';

			if (!memberId) {
				return;
			}

			const ok = confirm('해당 유저를 접속금지 처리하시겠습니까?');
			if (!ok) {
				return;
			}

			try {
				await postJson('/management/member/' + memberId + '/disable', {});
				alert('접속금지 처리되었습니다.\n(아이디: ' + username + ')');
			} catch (e) {
				alert('실패: ' + (e && e.message ? e.message : e));
			}
		});
	});

	/* =========================
	   2) 사업자등록증 열람 모달
	========================= */
	const licenseOpenBtn = document.getElementById('admin-client-detail-fourth-open-business-license');
	const noLicenseTextEl = document.getElementById('admin-client-detail-fourth-no-license-text');
	const businessLicenseModalEl = document.getElementById('admin-client-detail-fourth-businessLicenseModal');
	const businessLicenseImgEl = document.getElementById('admin-client-detail-fourth-businessLicenseImg');
	const businessLicenseFrameEl = document.getElementById('admin-client-detail-fourth-businessLicenseFrame');

	if (licenseOpenBtn) {
		licenseOpenBtn.addEventListener('click', function() {
			const url = licenseOpenBtn.getAttribute('data-license-url');

			if (!url) {
				return;
			}

			if (businessLicenseImgEl) {
				businessLicenseImgEl.style.display = 'none';
				businessLicenseImgEl.src = '';
			}

			if (businessLicenseFrameEl) {
				businessLicenseFrameEl.style.display = 'none';
				businessLicenseFrameEl.src = '';
			}

			if (isLikelyImageUrl(url)) {
				businessLicenseImgEl.src = url;
				businessLicenseImgEl.style.display = 'block';
			} else {
				businessLicenseFrameEl.src = url;
				businessLicenseFrameEl.style.display = 'block';
			}

			const modal = bootstrap.Modal.getOrCreateInstance(businessLicenseModalEl);
			modal.show();
		});
	}

	if (businessLicenseModalEl) {
		businessLicenseModalEl.addEventListener('hidden.bs.modal', function() {
			if (businessLicenseImgEl) {
				businessLicenseImgEl.src = '';
			}
			if (businessLicenseFrameEl) {
				businessLicenseFrameEl.src = '';
			}
		});
	}

	/* =========================
	   3) 회사정보 수정
	========================= */
	const companyId = window.ADMIN_CLIENT_DETAIL_FOURTH_COMPANY_ID;
	const companySaveBtn = document.getElementById('admin-client-detail-fourth-company-save-btn');
	const searchAddressBtn = document.getElementById('admin-client-detail-fourth-search-address-btn');
	const addressPreviewInlineEl = document.getElementById('admin-client-detail-fourth-address-preview-inline');
	const currentAddressPreviewEl = document.getElementById('admin-client-detail-fourth-current-address-preview');
	const salesManagerIdInput = document.getElementById('admin-client-detail-fourth-salesManagerId');
	const salesManagerSearchInput = document.getElementById('admin-client-detail-fourth-salesManagerSearch');
	const salesManagerClearBtn = document.getElementById('admin-client-detail-fourth-salesManagerClear');
	const salesManagerResultsEl = document.getElementById('admin-client-detail-fourth-salesManagerResults');
	const salesManagerStatusEl = document.getElementById('admin-client-detail-fourth-salesManagerStatus');
	let companySaving = false;

	const companyFields = {
		companyName: document.getElementById('admin-client-detail-fourth-companyName'),
		point: document.getElementById('admin-client-detail-fourth-point'),
		businessNumber: document.getElementById('admin-client-detail-fourth-businessNumber'),
		zipCode: document.getElementById('admin-client-detail-fourth-zipCode'),
		doName: document.getElementById('admin-client-detail-fourth-doName'),
		siName: document.getElementById('admin-client-detail-fourth-siName'),
		guName: document.getElementById('admin-client-detail-fourth-guName'),
		roadAddress: document.getElementById('admin-client-detail-fourth-roadAddress'),
		detailAddress: document.getElementById('admin-client-detail-fourth-detailAddress'),
		businessLicenseFile: document.getElementById('admin-client-detail-fourth-businessLicenseFile')
	};

	const existingLicenseUrlInput = document.getElementById('admin-client-detail-fourth-existing-license-url');
	const existingLicenseFilenameInput = document.getElementById('admin-client-detail-fourth-existing-license-filename');
	const licensePreviewListEl = document.getElementById('admin-client-detail-fourth-license-preview-list');

	const companyLicenseState = {
		existingUrl: existingLicenseUrlInput ? trimValue(existingLicenseUrlInput.value) : '',
		existingFilename: existingLicenseFilenameInput ? trimValue(existingLicenseFilenameInput.value) : '',
		existingRemoved: false,
		newFile: null,
		newFileObjectUrl: null
	};

	function revokeNewFileObjectUrl() {
		if (companyLicenseState.newFileObjectUrl) {
			URL.revokeObjectURL(companyLicenseState.newFileObjectUrl);
			companyLicenseState.newFileObjectUrl = null;
		}
	}

	function buildAddressPreviewText() {
		const text = joinAddressText([
			companyFields.roadAddress ? companyFields.roadAddress.value : '',
			companyFields.detailAddress ? companyFields.detailAddress.value : ''
		]);

		return text || '주소 정보 없음';
	}

	function updateAddressPreview() {
		const text = buildAddressPreviewText();

		if (addressPreviewInlineEl) {
			addressPreviewInlineEl.textContent = text;
		}

		if (currentAddressPreviewEl) {
			currentAddressPreviewEl.textContent = text;
		}
	}

	function updateLicenseStatusDisplay() {
		const showExistingOpen =
			!!licenseOpenBtn &&
			!!companyLicenseState.existingUrl &&
			!companyLicenseState.existingRemoved &&
			!companyLicenseState.newFile;

		if (licenseOpenBtn) {
			licenseOpenBtn.classList.toggle('d-none', !showExistingOpen);

			if (showExistingOpen) {
				licenseOpenBtn.setAttribute('data-license-url', companyLicenseState.existingUrl);
			}
		}

		if (noLicenseTextEl) {
			const showNoText = !showExistingOpen && !companyLicenseState.newFile;
			noLicenseTextEl.classList.toggle('d-none', !showNoText);
		}
	}

	function createLicensePreviewItem(kind, thumbMode, thumbValue, fileName) {
		const item = document.createElement('div');
		item.className = 'admin-client-detail-fourth-license-preview-item';

		const removeBtn = document.createElement('button');
		removeBtn.type = 'button';
		removeBtn.className = 'admin-client-detail-fourth-license-remove-btn';
		removeBtn.setAttribute('data-kind', kind);
		removeBtn.textContent = '×';

		const thumb = document.createElement('div');
		thumb.className = 'admin-client-detail-fourth-license-preview-thumb';

		if (thumbMode === 'image') {
			thumb.style.backgroundImage = 'url("' + thumbValue + '")';
		} else {
			thumb.textContent = thumbValue;
		}

		const meta = document.createElement('div');
		meta.className = 'admin-client-detail-fourth-license-preview-meta';

		const name = document.createElement('div');
		name.className = 'admin-client-detail-fourth-license-preview-name';
		name.textContent = fileName;

		meta.appendChild(name);
		item.appendChild(removeBtn);
		item.appendChild(thumb);
		item.appendChild(meta);

		return item;
	}

	function renderLicensePreview() {
		if (!licensePreviewListEl) {
			return;
		}

		licensePreviewListEl.innerHTML = '';

		if (companyLicenseState.newFile) {
			if (isImageFile(companyLicenseState.newFile)) {
				if (!companyLicenseState.newFileObjectUrl) {
					companyLicenseState.newFileObjectUrl = URL.createObjectURL(companyLicenseState.newFile);
				}

				licensePreviewListEl.appendChild(
					createLicensePreviewItem(
						'new',
						'image',
						companyLicenseState.newFileObjectUrl,
						companyLicenseState.newFile.name
					)
				);
			} else if (isPdfFile(companyLicenseState.newFile)) {
				licensePreviewListEl.appendChild(
					createLicensePreviewItem(
						'new',
						'text',
						'PDF 파일',
						companyLicenseState.newFile.name
					)
				);
			} else {
				licensePreviewListEl.appendChild(
					createLicensePreviewItem(
						'new',
						'text',
						'파일',
						companyLicenseState.newFile.name
					)
				);
			}

			updateLicenseStatusDisplay();
			return;
		}

		if (companyLicenseState.existingUrl && !companyLicenseState.existingRemoved) {
			if (isLikelyImageUrl(companyLicenseState.existingUrl)) {
				licensePreviewListEl.appendChild(
					createLicensePreviewItem(
						'existing',
						'image',
						companyLicenseState.existingUrl,
						companyLicenseState.existingFilename || '기존 사업자등록증'
					)
				);
			} else if (isLikelyPdfUrl(companyLicenseState.existingUrl)) {
				licensePreviewListEl.appendChild(
					createLicensePreviewItem(
						'existing',
						'text',
						'PDF 파일',
						companyLicenseState.existingFilename || '기존 사업자등록증'
					)
				);
			} else {
				licensePreviewListEl.appendChild(
					createLicensePreviewItem(
						'existing',
						'text',
						'기존 파일',
						companyLicenseState.existingFilename || '기존 사업자등록증'
					)
				);
			}
		}

		updateLicenseStatusDisplay();
	}

	function getLicenseAction() {
		if (companyLicenseState.newFile) {
			return 'REPLACE';
		}

		if (companyLicenseState.existingRemoved) {
			return 'DELETE';
		}

		return 'KEEP';
	}

	function createCompanySnapshot() {
		return JSON.stringify({
			companyName: trimValue(companyFields.companyName ? companyFields.companyName.value : ''),
			point: trimValue(companyFields.point ? companyFields.point.value : ''),
			businessNumber: normalizeBusinessNumber(companyFields.businessNumber ? companyFields.businessNumber.value : ''),
			zipCode: trimValue(companyFields.zipCode ? companyFields.zipCode.value : ''),
			doName: trimValue(companyFields.doName ? companyFields.doName.value : ''),
			siName: trimValue(companyFields.siName ? companyFields.siName.value : ''),
			guName: trimValue(companyFields.guName ? companyFields.guName.value : ''),
			roadAddress: trimValue(companyFields.roadAddress ? companyFields.roadAddress.value : ''),
			detailAddress: trimValue(companyFields.detailAddress ? companyFields.detailAddress.value : ''),
			salesManagerId: trimValue(salesManagerIdInput ? salesManagerIdInput.value : ''),
			existingRemoved: companyLicenseState.existingRemoved,
			hasNewFile: !!companyLicenseState.newFile,
			newFileName: companyLicenseState.newFile ? companyLicenseState.newFile.name : '',
			newFileSize: companyLicenseState.newFile ? companyLicenseState.newFile.size : 0
		});
	}

	const companyOriginalState = createCompanySnapshot();

	function validateCompanyForm() {
		const companyName = trimValue(companyFields.companyName.value);
		const point = trimValue(companyFields.point.value);
		const businessNumber = normalizeBusinessNumber(companyFields.businessNumber.value);
		const zipCode = trimValue(companyFields.zipCode.value);
		const doName = trimValue(companyFields.doName.value);
		const roadAddress = trimValue(companyFields.roadAddress.value);

		if (!companyName) {
			return false;
		}

		if (!isNonNegativeIntegerString(point)) {
			return false;
		}

		if (businessNumber.length !== 10) {
			return false;
		}

		if (!zipCode) {
			return false;
		}

		if (!doName) {
			return false;
		}

		if (!roadAddress) {
			return false;
		}

		// 텍스트만 입력한 값으로 임의 직원을 저장하지 않도록 검색 결과 선택을 강제합니다.
		if (salesManagerSearchInput && trimValue(salesManagerSearchInput.value)
			&& (!salesManagerIdInput || !trimValue(salesManagerIdInput.value))) {
			return false;
		}

		return true;
	}

	function hasCompanyChanges() {
		return createCompanySnapshot() !== companyOriginalState;
	}

	function toggleCompanySaveButton() {
		if (!companySaveBtn) {
			return;
		}

		companySaveBtn.disabled = companySaving || !(validateCompanyForm() && hasCompanyChanges());
	}

	/* 담당직원 자동완성: 서버가 활성 상태의 우리회사 관리팀 소속 ADMIN / MANAGEMENT만 반환합니다. */
	const salesManagerState = {
		items: [],
		activeIndex: -1,
		requestSequence: 0,
		debounceTimer: null
	};

	function salesManagerLabel(item) {
		return trimValue(item && item.username);
	}

	function salesManagerDisplayName(item) {
		const username = salesManagerLabel(item);
		const name = trimValue(item && item.name);
		return name ? username + ' · ' + name : username;
	}

	function setSalesManagerStatus(message, isError) {
		if (!salesManagerStatusEl) {
			return;
		}

		salesManagerStatusEl.textContent = message;
		salesManagerStatusEl.classList.toggle('text-danger', !!isError);
	}

	function closeSalesManagerResults() {
		if (!salesManagerResultsEl || !salesManagerSearchInput) {
			return;
		}

		salesManagerResultsEl.classList.add('d-none');
		salesManagerSearchInput.setAttribute('aria-expanded', 'false');
		salesManagerSearchInput.removeAttribute('aria-activedescendant');
		salesManagerState.activeIndex = -1;
	}

	function updateSalesManagerActiveResult() {
		if (!salesManagerResultsEl || !salesManagerSearchInput) {
			return;
		}

		const options = Array.from(salesManagerResultsEl.querySelectorAll('[role="option"]'));
		options.forEach(function(option, index) {
			const active = index === salesManagerState.activeIndex;
			option.classList.toggle('active', active);
			option.setAttribute('aria-selected', active ? 'true' : 'false');
		});

		const activeOption = options[salesManagerState.activeIndex];
		if (activeOption) {
			salesManagerSearchInput.setAttribute('aria-activedescendant', activeOption.id);
			activeOption.scrollIntoView({ block: 'nearest' });
		} else {
			salesManagerSearchInput.removeAttribute('aria-activedescendant');
		}
	}

	function chooseSalesManager(item) {
		if (!salesManagerIdInput || !salesManagerSearchInput || !item) {
			return;
		}

		const label = salesManagerLabel(item);
		window.clearTimeout(salesManagerState.debounceTimer);
		salesManagerState.requestSequence++;
		salesManagerIdInput.value = nvl(item.id);
		salesManagerSearchInput.value = label;
		salesManagerSearchInput.setAttribute('data-selected-label', label);
		setSalesManagerStatus(salesManagerDisplayName(item) + ' 담당직원이 선택되었습니다.', false);
		closeSalesManagerResults();
		toggleCompanySaveButton();
	}

	function clearSalesManager() {
		window.clearTimeout(salesManagerState.debounceTimer);
		salesManagerState.requestSequence++;
		if (salesManagerIdInput) {
			salesManagerIdInput.value = '';
		}

		if (salesManagerSearchInput) {
			salesManagerSearchInput.value = '';
			salesManagerSearchInput.setAttribute('data-selected-label', '');
		}

		setSalesManagerStatus('담당직원 지정을 해제했습니다. 저장 버튼을 눌러 반영해 주세요.', false);
		closeSalesManagerResults();
		toggleCompanySaveButton();
	}

	function renderSalesManagerResults(items) {
		if (!salesManagerResultsEl || !salesManagerSearchInput) {
			return;
		}

		salesManagerResultsEl.replaceChildren();
		salesManagerState.items = Array.isArray(items) ? items : [];
		salesManagerState.activeIndex = salesManagerState.items.length > 0 ? 0 : -1;

		if (salesManagerState.items.length === 0) {
			const empty = document.createElement('div');
			empty.className = 'admin-client-detail-sales-manager-empty';
			empty.textContent = '조건에 맞는 담당직원이 없습니다.';
			salesManagerResultsEl.appendChild(empty);
			setSalesManagerStatus('활성 상태인 우리회사 관리팀 소속 ADMIN 또는 MANAGEMENT 계정만 검색됩니다.', false);
		} else {
			salesManagerState.items.forEach(function(item, index) {
				const option = document.createElement('button');
				option.type = 'button';
				option.id = 'admin-client-detail-sales-manager-option-' + index;
				option.className = 'admin-client-detail-sales-manager-option';
				option.setAttribute('role', 'option');
				option.setAttribute('aria-selected', index === 0 ? 'true' : 'false');

				const identity = document.createElement('span');
				identity.className = 'admin-client-detail-sales-manager-identity';
				identity.textContent = salesManagerDisplayName(item);

				const meta = document.createElement('span');
				meta.className = 'admin-client-detail-sales-manager-meta';
				meta.textContent = [trimValue(item.role), trimValue(item.teamName)]
					.filter(Boolean).join(' · ') || '소속 정보 없음';

				option.appendChild(identity);
				option.appendChild(meta);
				option.addEventListener('mousedown', function(event) {
					// 입력창 blur보다 먼저 선택을 확정합니다.
					event.preventDefault();
					chooseSalesManager(item);
				});
				salesManagerResultsEl.appendChild(option);
			});
			setSalesManagerStatus(salesManagerState.items.length + '명의 검색 결과가 있습니다.', false);
		}

		salesManagerResultsEl.classList.remove('d-none');
		salesManagerSearchInput.setAttribute('aria-expanded', 'true');
		updateSalesManagerActiveResult();
	}

	async function searchSalesManagers() {
		if (!salesManagerSearchInput) {
			return;
		}

		const requestSequence = ++salesManagerState.requestSequence;
		setSalesManagerStatus('담당직원을 검색하는 중입니다.', false);

		try {
			const items = await getJson(
				'/management/api/sales-managers/search?keyword=' + encodeURIComponent(trimValue(salesManagerSearchInput.value))
			);
			if (requestSequence !== salesManagerState.requestSequence) {
				return;
			}
			renderSalesManagerResults(items);
		} catch (error) {
			if (requestSequence !== salesManagerState.requestSequence) {
				return;
			}
			salesManagerState.items = [];
			closeSalesManagerResults();
			setSalesManagerStatus('담당직원 검색에 실패했습니다. 잠시 후 다시 시도해 주세요.', true);
		}
	}

	if (salesManagerSearchInput) {
		salesManagerSearchInput.addEventListener('input', function() {
			// 선택 문구를 수정하면 기존 선택 ID를 즉시 지워 다른 직원으로 잘못 저장되는 것을 방지합니다.
			salesManagerState.requestSequence++;
			salesManagerState.items = [];
			closeSalesManagerResults();
			if (salesManagerIdInput) {
				salesManagerIdInput.value = '';
			}
			toggleCompanySaveButton();

			window.clearTimeout(salesManagerState.debounceTimer);
			salesManagerState.debounceTimer = window.setTimeout(searchSalesManagers, 180);
		});

		salesManagerSearchInput.addEventListener('focus', function() {
			window.clearTimeout(salesManagerState.debounceTimer);
			salesManagerState.debounceTimer = window.setTimeout(searchSalesManagers, 0);
		});

		salesManagerSearchInput.addEventListener('keydown', function(event) {
			if (event.key === 'Escape') {
				closeSalesManagerResults();
				return;
			}

			if (!salesManagerResultsEl || salesManagerResultsEl.classList.contains('d-none')) {
				if (event.key === 'Enter') {
					event.preventDefault();
					window.clearTimeout(salesManagerState.debounceTimer);
					searchSalesManagers().then(function() {
						const first = salesManagerState.items[0];
						if (first) {
							chooseSalesManager(first);
						}
					});
				}
				return;
			}

			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();
				const count = salesManagerState.items.length;
				if (count === 0) {
					return;
				}
				const direction = event.key === 'ArrowDown' ? 1 : -1;
				salesManagerState.activeIndex = (salesManagerState.activeIndex + direction + count) % count;
				updateSalesManagerActiveResult();
				return;
			}

			if (event.key === 'Enter') {
				event.preventDefault();
				const selected = salesManagerState.items[salesManagerState.activeIndex];
				if (selected) {
					chooseSalesManager(selected);
				}
			}
		});
	}

	if (salesManagerClearBtn) {
		salesManagerClearBtn.addEventListener('click', function() {
			clearSalesManager();
			if (salesManagerSearchInput) {
				salesManagerSearchInput.focus();
			}
		});
	}

	document.addEventListener('click', function(event) {
		const target = event.target;
		if (!(target instanceof Element) || !target.closest('[data-sales-manager-autocomplete]')) {
			closeSalesManagerResults();
		}
	});

	function openAddressSearch() {
		const Postcode = getPostcodeConstructor();

		if (!Postcode) {
			alert('주소 검색 스크립트가 아직 로드되지 않았습니다. 새로고침 후 다시 시도해주세요.');
			return;
		}

		new Postcode({
			oncomplete: function(data) {
				const region = resolvePostcodeRegion(data);

				companyFields.zipCode.value = trimValue(region.zipCode);
				companyFields.doName.value = trimValue(region.doName);
				companyFields.siName.value = trimValue(region.siName);
				companyFields.guName.value = trimValue(region.guName);
				companyFields.roadAddress.value = trimValue(region.roadAddress);

				updateAddressPreview();
				toggleCompanySaveButton();

				if (companyFields.detailAddress) {
					companyFields.detailAddress.focus();
				}
			}
		}).open();
	}

	Object.keys(companyFields).forEach(function(key) {
		const field = companyFields[key];

		if (!field || key === 'businessLicenseFile') {
			return;
		}

		field.addEventListener('input', function() {
			if (key === 'businessNumber') {
				field.value = normalizeBusinessNumber(field.value);
			}

			updateAddressPreview();
			toggleCompanySaveButton();
		});

		field.addEventListener('change', function() {
			if (key === 'businessNumber') {
				field.value = normalizeBusinessNumber(field.value);
			}

			updateAddressPreview();
			toggleCompanySaveButton();
		});
	});

	if (companyFields.businessLicenseFile) {
		companyFields.businessLicenseFile.addEventListener('change', function(e) {
			revokeNewFileObjectUrl();

			const file = e.target.files && e.target.files[0] ? e.target.files[0] : null;
			companyLicenseState.newFile = file;

			renderLicensePreview();
			toggleCompanySaveButton();
		});
	}

	if (licensePreviewListEl) {
		licensePreviewListEl.addEventListener('click', function(e) {
			const btn = e.target.closest('.admin-client-detail-fourth-license-remove-btn');

			if (!btn) {
				return;
			}

			const kind = btn.getAttribute('data-kind');

			if (kind === 'existing') {
				companyLicenseState.existingRemoved = true;
			}

			if (kind === 'new') {
				revokeNewFileObjectUrl();
				companyLicenseState.newFile = null;

				if (companyFields.businessLicenseFile) {
					companyFields.businessLicenseFile.value = '';
				}
			}

			renderLicensePreview();
			toggleCompanySaveButton();
		});
	}

	if (searchAddressBtn) {
		searchAddressBtn.addEventListener('click', openAddressSearch);
	}

	if (companySaveBtn) {
		companySaveBtn.addEventListener('click', async function() {
			if (companySaving) {
				return;
			}

			if (!validateCompanyForm()) {
				if (salesManagerSearchInput && trimValue(salesManagerSearchInput.value)
					&& (!salesManagerIdInput || !trimValue(salesManagerIdInput.value))) {
					alert('담당직원은 검색 결과에서 선택해 주세요. 아이디 텍스트만 입력한 상태로는 저장할 수 없습니다.');
					return;
				}
				alert('업체명, 적립금(0 이상), 사업자등록번호(숫자 10자리), 우편번호와 주소를 확인해주세요.');
				return;
			}

			const ok = confirm('회사정보 수정사항을 반영하시겠습니까?');
			if (!ok) {
				return;
			}

			const formData = new FormData();
			formData.append('companyName', trimValue(companyFields.companyName.value));
			formData.append('point', trimValue(companyFields.point.value));
			formData.append('businessNumber', normalizeBusinessNumber(companyFields.businessNumber.value));
			formData.append('zipCode', trimValue(companyFields.zipCode.value));
			formData.append('doName', trimValue(companyFields.doName.value));
			formData.append('siName', trimValue(companyFields.siName.value));
			formData.append('guName', trimValue(companyFields.guName.value));
			formData.append('roadAddress', trimValue(companyFields.roadAddress.value));
			formData.append('detailAddress', trimValue(companyFields.detailAddress.value));
			formData.append('salesManagerId', trimValue(salesManagerIdInput ? salesManagerIdInput.value : ''));
			formData.append('salesManagerAssignmentIncluded', 'true');
			formData.append('licenseAction', getLicenseAction());

			if (companyLicenseState.newFile) {
				formData.append('businessLicenseFile', companyLicenseState.newFile);
			}

			companySaving = true;
			companySaveBtn.textContent = '저장 중...';
			toggleCompanySaveButton();

			try {
				await postFormData('/management/clientDetail/' + companyId + '/updateCompany', formData);
				alert('회사정보가 수정되었습니다.');
				location.reload();
			} catch (e) {
				alert('실패: ' + (e && e.message ? e.message : e));
			} finally {
				companySaving = false;
				companySaveBtn.textContent = '수정사항 반영';
				toggleCompanySaveButton();
			}
		});
	}

	updateAddressPreview();
	renderLicensePreview();
	toggleCompanySaveButton();

	/* =========================
	   4) 자주 사용하는 배송지 관리
	========================= */
	const deliveryAddressOpenBtn = document.getElementById('admin-client-detail-fourth-delivery-address-open-btn');
	const deliveryAddressModalEl = document.getElementById('admin-client-detail-fourth-deliveryAddressModal');
	const deliveryAddressModal = deliveryAddressModalEl
		? bootstrap.Modal.getOrCreateInstance(deliveryAddressModalEl)
		: null;

	const deliveryAddressSearchBtn = document.getElementById('admin-client-detail-fourth-delivery-address-search-btn');
	const deliveryAddressSaveBtn = document.getElementById('admin-client-detail-fourth-delivery-address-save-btn');
	const deliveryAddressZipCodeInput = document.getElementById('admin-client-detail-fourth-delivery-address-zipCode');
	const deliveryAddressRoadAddressInput = document.getElementById('admin-client-detail-fourth-delivery-address-roadAddress');
	const deliveryAddressDetailAddressInput = document.getElementById('admin-client-detail-fourth-delivery-address-detailAddress');
	const deliveryAddressPreviewEl = document.getElementById('admin-client-detail-fourth-delivery-address-preview');
	const deliveryAddressListEl = document.getElementById('admin-client-detail-fourth-delivery-address-list');
	const deliveryAddressLoadingEl = document.getElementById('admin-client-detail-fourth-delivery-address-loading');
	const deliveryAddressEmptyEl = document.getElementById('admin-client-detail-fourth-delivery-address-empty');
	const deliveryAddressListCountEl = document.getElementById('admin-client-detail-fourth-delivery-address-list-count');
	const deliveryAddressSummaryCountEl = document.getElementById('admin-client-detail-fourth-delivery-address-summary-count');

	function parseDeliveryAddressInitialCount() {
		if (!deliveryAddressSummaryCountEl) {
			return 0;
		}

		const raw = trimValue(deliveryAddressSummaryCountEl.getAttribute('data-initial-count'));
		const parsed = Number.parseInt(raw, 10);
		return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
	}

	const deliveryAddressState = {
		items: [],
		loaded: false,
		totalCount: parseDeliveryAddressInitialCount(),
		candidate: null,
		loading: false,
		saving: false,
		deletingIds: new Set()
	};

	function buildDeliveryAddressText(address) {
		if (!address) {
			return '';
		}

		return joinAddressText([
			address.roadAddress,
			address.detailAddress
		]);
	}

	function updateDeliveryAddressCount() {
		const count = deliveryAddressState.loaded
			? deliveryAddressState.items.length
			: deliveryAddressState.totalCount;

		if (deliveryAddressListCountEl) {
			deliveryAddressListCountEl.textContent = count + '개';
		}

		if (deliveryAddressSummaryCountEl) {
			deliveryAddressSummaryCountEl.textContent = count + '개 등록';
		}
	}

	function toggleDeliveryAddressSaveButton() {
		if (!deliveryAddressSaveBtn) {
			return;
		}

		const candidate = deliveryAddressState.candidate;
		const validCandidate = !!candidate &&
			!!trimValue(candidate.zipCode) &&
			!!trimValue(candidate.doName) &&
			!!trimValue(candidate.roadAddress);

		deliveryAddressSaveBtn.disabled = deliveryAddressState.saving || !validCandidate;
		deliveryAddressSaveBtn.textContent = deliveryAddressState.saving ? '추가 중...' : '배송지 추가';
	}

	function renderDeliveryAddressCandidate() {
		const candidate = deliveryAddressState.candidate;

		if (deliveryAddressZipCodeInput) {
			deliveryAddressZipCodeInput.value = candidate ? trimValue(candidate.zipCode) : '';
		}

		if (deliveryAddressRoadAddressInput) {
			deliveryAddressRoadAddressInput.value = candidate ? trimValue(candidate.roadAddress) : '';
		}

		if (deliveryAddressPreviewEl) {
			const previewAddress = candidate ? Object.assign({}, candidate, {
				detailAddress: deliveryAddressDetailAddressInput
					? trimValue(deliveryAddressDetailAddressInput.value)
					: ''
			}) : null;

			const previewText = buildDeliveryAddressText(previewAddress);
			deliveryAddressPreviewEl.textContent = previewText;
			deliveryAddressPreviewEl.classList.toggle('d-none', !previewText);
		}

		toggleDeliveryAddressSaveButton();
	}

	function resetDeliveryAddressCandidate() {
		deliveryAddressState.candidate = null;

		if (deliveryAddressDetailAddressInput) {
			deliveryAddressDetailAddressInput.value = '';
		}

		renderDeliveryAddressCandidate();
	}

	function createDeliveryAddressListItem(address) {
		const wrapper = document.createElement('div');
		wrapper.className = 'border rounded p-3 mb-2';

		const row = document.createElement('div');
		row.className = 'd-flex justify-content-between align-items-start gap-3';

		const content = document.createElement('div');
		content.className = 'flex-grow-1';

		const addressText = document.createElement('div');
		addressText.className = 'fw-medium text-break';
		addressText.textContent = buildDeliveryAddressText(address) || '주소 정보 없음';

		const regionText = document.createElement('div');
		regionText.className = 'text-muted small mt-1';
		regionText.textContent = joinAddressText([
			address.doName,
			address.siName,
			address.guName
		]) || '-';

		const deleteBtn = document.createElement('button');
		deleteBtn.type = 'button';
		deleteBtn.className = 'btn btn-sm btn-outline-danger flex-shrink-0';
		deleteBtn.setAttribute('data-delivery-address-id', nvl(address.id));
		deleteBtn.setAttribute('aria-label', '배송지 삭제');
		deleteBtn.title = '배송지 삭제';
		deleteBtn.textContent = '×';
		deleteBtn.disabled = deliveryAddressState.deletingIds.has(String(address.id));

		content.appendChild(addressText);
		content.appendChild(regionText);
		row.appendChild(content);
		row.appendChild(deleteBtn);
		wrapper.appendChild(row);

		return wrapper;
	}

	function renderDeliveryAddressList() {
		if (deliveryAddressLoadingEl) {
			deliveryAddressLoadingEl.classList.toggle('d-none', !deliveryAddressState.loading);
		}

		if (deliveryAddressListEl) {
			deliveryAddressListEl.innerHTML = '';

			if (!deliveryAddressState.loading) {
				deliveryAddressState.items.forEach(function(address) {
					deliveryAddressListEl.appendChild(createDeliveryAddressListItem(address));
				});
			}
		}

		if (deliveryAddressEmptyEl) {
			const showEmpty = deliveryAddressState.loaded
				&& !deliveryAddressState.loading
				&& deliveryAddressState.items.length === 0;
			deliveryAddressEmptyEl.classList.toggle('d-none', !showEmpty);
		}

		updateDeliveryAddressCount();
	}

	function applyDeliveryAddressResponse(response) {
		if (!response || response.success === false) {
			throw new Error(response && response.message ? response.message : '배송지 처리 결과가 올바르지 않습니다.');
		}

		deliveryAddressState.items = Array.isArray(response.addresses) ? response.addresses : [];
		deliveryAddressState.loaded = true;
		deliveryAddressState.totalCount = deliveryAddressState.items.length;
		renderDeliveryAddressList();
	}

	async function loadDeliveryAddresses() {
		if (!companyId || deliveryAddressState.loading) {
			return;
		}

		deliveryAddressState.loading = true;
		renderDeliveryAddressList();

		try {
			const response = await getJson('/management/clientDetail/' + companyId + '/deliveryAddresses');
			applyDeliveryAddressResponse(response);
		} catch (e) {
			alert('배송지 조회 실패: ' + (e && e.message ? e.message : e));
		} finally {
			deliveryAddressState.loading = false;
			renderDeliveryAddressList();
		}
	}

	function openDeliveryAddressSearch() {
		const Postcode = getPostcodeConstructor();

		if (!Postcode) {
			alert('주소 검색 스크립트가 아직 로드되지 않았습니다. 새로고침 후 다시 시도해주세요.');
			return;
		}

		new Postcode({
			oncomplete: function(data) {
				const region = resolvePostcodeRegion(data);

				deliveryAddressState.candidate = {
					zipCode: trimValue(region.zipCode),
					doName: trimValue(region.doName),
					siName: trimValue(region.siName),
					guName: trimValue(region.guName),
					roadAddress: trimValue(region.roadAddress)
				};

				if (deliveryAddressDetailAddressInput) {
					deliveryAddressDetailAddressInput.value = '';
				}

				renderDeliveryAddressCandidate();

				if (deliveryAddressDetailAddressInput) {
					deliveryAddressDetailAddressInput.focus();
				}
			}
		}).open();
	}

	if (deliveryAddressOpenBtn) {
		deliveryAddressOpenBtn.addEventListener('click', function() {
			if (deliveryAddressModal) {
				deliveryAddressModal.show();
			}
		});
	}

	if (deliveryAddressModalEl) {
		deliveryAddressModalEl.addEventListener('shown.bs.modal', function() {
			loadDeliveryAddresses();
		});
	}

	if (deliveryAddressSearchBtn) {
		deliveryAddressSearchBtn.addEventListener('click', openDeliveryAddressSearch);
	}

	if (deliveryAddressDetailAddressInput) {
		deliveryAddressDetailAddressInput.addEventListener('input', renderDeliveryAddressCandidate);
	}

	if (deliveryAddressSaveBtn) {
		deliveryAddressSaveBtn.addEventListener('click', async function() {
			const candidate = deliveryAddressState.candidate;

			if (!candidate || !trimValue(candidate.zipCode) || !trimValue(candidate.doName) || !trimValue(candidate.roadAddress)) {
				alert('주소 검색을 통해 추가할 배송지를 선택해주세요.');
				return;
			}

			deliveryAddressState.saving = true;
			toggleDeliveryAddressSaveButton();

			try {
				const response = await postJson('/management/clientDetail/' + companyId + '/deliveryAddresses', {
					zipCode: trimValue(candidate.zipCode),
					doName: trimValue(candidate.doName),
					siName: trimValue(candidate.siName),
					guName: trimValue(candidate.guName),
					roadAddress: trimValue(candidate.roadAddress),
					detailAddress: deliveryAddressDetailAddressInput
						? trimValue(deliveryAddressDetailAddressInput.value)
						: ''
				});

				applyDeliveryAddressResponse(response);
				resetDeliveryAddressCandidate();
				alert('배송지가 추가되었습니다.');
			} catch (e) {
				alert('배송지 추가 실패: ' + (e && e.message ? e.message : e));
			} finally {
				deliveryAddressState.saving = false;
				toggleDeliveryAddressSaveButton();
			}
		});
	}

	if (deliveryAddressListEl) {
		deliveryAddressListEl.addEventListener('click', async function(e) {
			const deleteBtn = e.target.closest('[data-delivery-address-id]');

			if (!deleteBtn) {
				return;
			}

			const addressId = trimValue(deleteBtn.getAttribute('data-delivery-address-id'));
			if (!addressId || deliveryAddressState.deletingIds.has(addressId)) {
				return;
			}

			const address = deliveryAddressState.items.find(function(item) {
				return String(item.id) === addressId;
			});

			const message = address
				? '다음 배송지를 삭제하시겠습니까?\n\n' + buildDeliveryAddressText(address)
				: '선택한 배송지를 삭제하시겠습니까?';

			if (!confirm(message)) {
				return;
			}

			deliveryAddressState.deletingIds.add(addressId);
			renderDeliveryAddressList();

			try {
				const response = await deleteJson(
					'/management/clientDetail/' + companyId + '/deliveryAddresses/' + encodeURIComponent(addressId)
				);
				applyDeliveryAddressResponse(response);
			} catch (e) {
				alert('배송지 삭제 실패: ' + (e && e.message ? e.message : e));
			} finally {
				deliveryAddressState.deletingIds.delete(addressId);
				renderDeliveryAddressList();
			}
		});
	}

	renderDeliveryAddressCandidate();
	renderDeliveryAddressList();

	/* =========================
	   5) 회원정보 수정 모달
	========================= */
	const memberEditModalEl = document.getElementById('admin-client-detail-fourth-memberEditModal');
	const memberEditModal = memberEditModalEl ? bootstrap.Modal.getOrCreateInstance(memberEditModalEl) : null;

	const memberInputs = {
		id: document.getElementById('admin-client-detail-fourth-member-id'),
		name: document.getElementById('admin-client-detail-fourth-member-name'),
		phone: document.getElementById('admin-client-detail-fourth-member-phone'),
		email: document.getElementById('admin-client-detail-fourth-member-email'),
		telephone: document.getElementById('admin-client-detail-fourth-member-telephone')
	};

	const memberSaveBtn = document.getElementById('admin-client-detail-fourth-member-save-btn');
	let memberOriginalState = '';

	function serializeMemberForm() {
		return JSON.stringify({
			name: trimValue(memberInputs.name.value),
			phone: trimValue(memberInputs.phone.value),
			email: trimValue(memberInputs.email.value),
			telephone: trimValue(memberInputs.telephone.value)
		});
	}

	function validateMemberForm() {
		const name = trimValue(memberInputs.name.value);
		const phone = trimValue(memberInputs.phone.value);
		const email = trimValue(memberInputs.email.value);

		if (!name) {
			return false;
		}

		if (!phone) {
			return false;
		}

		if (email) {
			const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
			if (!emailRegex.test(email)) {
				return false;
			}
		}

		return true;
	}

	function toggleMemberSaveButton() {
		if (!memberSaveBtn) {
			return;
		}

		memberSaveBtn.disabled = !(validateMemberForm() && serializeMemberForm() !== memberOriginalState);
	}

	document.querySelectorAll('.admin-client-detail-fourth-edit-member-btn').forEach(function(btn) {
		btn.addEventListener('click', function() {
			memberInputs.id.value = btn.getAttribute('data-member-id') || '';
			memberInputs.name.value = btn.getAttribute('data-member-name') || '';
			memberInputs.phone.value = btn.getAttribute('data-member-phone') || '';
			memberInputs.email.value = btn.getAttribute('data-member-email') || '';
			memberInputs.telephone.value = btn.getAttribute('data-member-telephone') || '';

			memberOriginalState = serializeMemberForm();
			toggleMemberSaveButton();

			if (memberEditModal) {
				memberEditModal.show();
			}
		});
	});

	if (memberEditModalEl) {
		memberEditModalEl.addEventListener('shown.bs.modal', function() {
			if (memberInputs.name) {
				memberInputs.name.focus();
			}
		});
	}

	['name', 'phone', 'email', 'telephone'].forEach(function(key) {
		if (!memberInputs[key]) {
			return;
		}

		memberInputs[key].addEventListener('input', toggleMemberSaveButton);
		memberInputs[key].addEventListener('change', toggleMemberSaveButton);
	});

	if (memberSaveBtn) {
		memberSaveBtn.addEventListener('click', async function() {
			if (!validateMemberForm()) {
				alert('이름 / 연락처를 확인해주세요. 이메일 형식도 확인해주세요.');
				return;
			}

			const memberId = memberInputs.id.value;

			if (!memberId) {
				alert('회원 식별자가 없습니다.');
				return;
			}

			const ok = confirm('고객정보 수정사항을 반영하시겠습니까?');
			if (!ok) {
				return;
			}

			try {
				await postJson('/management/member/' + memberId + '/updateInfo', {
					name: trimValue(memberInputs.name.value),
					phone: trimValue(memberInputs.phone.value),
					email: trimValue(memberInputs.email.value),
					telephone: trimValue(memberInputs.telephone.value)
				});

				alert('고객정보가 수정되었습니다.');
				location.reload();
			} catch (e) {
				alert('실패: ' + (e && e.message ? e.message : e));
			}
		});
	}
})();
