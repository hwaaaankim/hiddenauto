document.addEventListener("DOMContentLoaded", function() {
	'use strict';

	const form = document.getElementById("as-management-third-form");
	if (!form) return;

	try {
		if (window.bootstrap && document.querySelectorAll('[data-bs-toggle="tooltip"]').length > 0) {
			[...document.querySelectorAll('[data-bs-toggle="tooltip"]')].forEach(
				el => new bootstrap.Tooltip(el)
			);
		}
	} catch (e) { /* ignore */ }

	const saveBtn = document.getElementById("as-management-third-saveBtn");
	const dirtyBadge = document.getElementById("as-management-third-dirtyBadge");

	const companyIdEl = document.getElementById("as-management-third-companyId");
	const companyNameDisplay = document.getElementById("as-management-third-companyNameDisplay");
	const requestedByNameDisplay = document.getElementById("as-management-third-requestedByNameDisplay");
	const companyEditBtn = document.getElementById("as-management-third-companyEditBtn");
	const companySearchWrap = document.getElementById("as-management-third-companySearchWrap");
	const companyKeywordEl = document.getElementById("as-management-third-companyKeyword");
	const companyResultsEl = document.getElementById("as-management-third-companyResults");

	const addressEditBtn = document.getElementById("as-management-third-addressEditBtn");
	const addressModalEl = document.getElementById("as-management-third-addressModal");
	const addressSearchBtn = document.getElementById("as-management-third-addressSearchBtn");
	const addressConfirmBtn = document.getElementById("as-management-third-addressConfirmBtn");

	const zipCodeEl = document.getElementById("as-management-third-zipCode");
	const doNameEl = document.getElementById("as-management-third-doName");
	const siNameEl = document.getElementById("as-management-third-siName");
	const guNameEl = document.getElementById("as-management-third-guName");
	const roadAddressEl = document.getElementById("as-management-third-roadAddress");
	const detailAddressEl = document.getElementById("as-management-third-detailAddress");

	const modalZip = document.getElementById("as-management-third-modalZip");
	const modalDo = document.getElementById("as-management-third-modalDo");
	const modalSi = document.getElementById("as-management-third-modalSi");
	const modalGu = document.getElementById("as-management-third-modalGu");
	const modalRoad = document.getElementById("as-management-third-modalRoad");
	const modalDetail = document.getElementById("as-management-third-modalDetail");

	const customerNameEl = document.getElementById("as-management-third-customerName");
	const onsiteContactEl = document.getElementById("as-management-third-onsiteContact");
	const productNameEl = document.getElementById("as-management-third-productName");
	const productSizeEl = document.getElementById("as-management-third-productSize");
	const productColorEl = document.getElementById("as-management-third-productColor");
	const productOptionsEl = document.getElementById("as-management-third-productOptions");

	const applicantNameEl = document.getElementById("as-management-third-applicantName");
	const applicantPhoneEl = document.getElementById("as-management-third-applicantPhone");
	const applicantEmailEl = document.getElementById("as-management-third-applicantEmail");
	const purchaseDateEl = document.getElementById("as-management-third-purchaseDate");
	const billingTargetEl = document.getElementById("as-management-third-billingTarget");

	const adminMemoEl = document.getElementById("as-management-third-adminMemo");

	const subjectInputEl = document.getElementById("as-management-third-subjectInput");
	const subjectCategoryEl = document.getElementById("as-management-third-subjectCategory");
	const subjectSymptomEl = document.getElementById("as-management-third-subjectSymptom");

	const priceEl = document.getElementById("as-management-third-price");
	const priceReadonlyHelpEl = document.getElementById("as-management-third-priceReadonlyHelp");
	const paymentCollectedEl = document.getElementById("as-management-third-paymentCollected");
	const statusEl = document.getElementById("as-management-third-status");
	const assignedHandlerEl = document.getElementById("as-management-third-assignedHandlerId");

	const existingImagesWrap = document.getElementById("as-management-third-existingRequestImages");
	const deleteRequestImageIdsEl = document.getElementById("as-management-third-deleteRequestImageIds");

	const existingVideosWrap = document.getElementById("as-management-third-existingRequestVideos");
	const deleteRequestVideoIdsEl = document.getElementById("as-management-third-deleteRequestVideoIds");

	const uploadBtn = document.getElementById("as-management-third-uploadBtn");
	const newImagesInput = document.getElementById("as-management-third-newRequestImages");
	const previewList = document.getElementById("as-management-third-previewList");

	const uploadVideoBtn = document.getElementById("as-management-third-uploadVideoBtn");
	const newVideosInput = document.getElementById("as-management-third-newRequestVideos");
	const previewVideoList = document.getElementById("as-management-third-previewVideoList");

	const deleteBtn = document.getElementById("as-management-third-deleteBtn");
	const deleteForm = document.getElementById("as-management-third-deleteForm");

	const existingResultImagesWrap = document.getElementById("as-management-third-existingResultImages");
	const existingResultVideosWrap = document.getElementById("as-management-third-existingResultVideos");

	const mediaPreviewModalEl = document.getElementById("as-management-third-mediaPreviewModal");
	const mediaPreviewTitleEl = document.getElementById("as-management-third-mediaPreviewTitle");
	const mediaPreviewBodyEl = document.getElementById("as-management-third-mediaPreviewBody");

	const initial = {
		companyId: (companyIdEl?.value || "").trim(),
		zipCode: (zipCodeEl?.value || "").trim(),
		doName: (doNameEl?.value || "").trim(),
		siName: (siNameEl?.value || "").trim(),
		guName: (guNameEl?.value || "").trim(),
		roadAddress: (roadAddressEl?.value || "").trim(),
		detailAddress: (detailAddressEl?.value || "").trim(),

		customerName: (customerNameEl?.value || "").trim(),
		onsiteContact: (onsiteContactEl?.value || "").trim(),
		productName: (productNameEl?.value || "").trim(),
		productSize: (productSizeEl?.value || "").trim(),
		productColor: (productColorEl?.value || "").trim(),
		productOptions: (productOptionsEl?.value || "").trim(),

		applicantName: (applicantNameEl?.value || "").trim(),
		applicantPhone: (applicantPhoneEl?.value || "").trim(),
		applicantEmail: (applicantEmailEl?.value || "").trim(),
		purchaseDate: (purchaseDateEl?.value || "").trim(),
		billingTarget: (billingTargetEl?.value || "").trim(),

		adminMemo: (adminMemoEl?.value || "").trim(),
		subject: (subjectInputEl?.value || "").trim(),

		price: (priceEl?.value || "").trim(),
		paymentCollected: (paymentCollectedEl?.value || "").trim(),
		status: (statusEl?.value || "").trim(),
		assignedHandlerId: (assignedHandlerEl?.value || "").trim()
	};

	let deletedRequestImageIds = [];
	let deletedRequestVideoIds = [];
	let companySearchOpen = false;

	function getV(el) {
		return (el && typeof el.value === "string") ? el.value.trim() : "";
	}

	function isCompletedStatus() {
		return getV(statusEl) === "COMPLETED";
	}

	function syncPriceReadonly() {
		if (!priceEl) return;

		const readonly = isCompletedStatus();

		priceEl.readOnly = readonly;

		if (readonly) {
			priceEl.classList.add("bg-light", "text-muted");
			if (priceReadonlyHelpEl) {
				priceReadonlyHelpEl.classList.remove("d-none");
			}
		} else {
			priceEl.classList.remove("bg-light", "text-muted");
			if (priceReadonlyHelpEl) {
				priceReadonlyHelpEl.classList.add("d-none");
			}
		}
	}

	function setDirty(isDirty) {
		if (!saveBtn || !dirtyBadge) return;

		saveBtn.disabled = !isDirty;

		if (isDirty) {
			dirtyBadge.textContent = "변경사항 있음";
			dirtyBadge.classList.remove("bg-light", "text-dark");
			dirtyBadge.classList.add("bg-warning", "text-dark");
		} else {
			dirtyBadge.textContent = "변경사항 없음";
			dirtyBadge.classList.remove("bg-warning");
			dirtyBadge.classList.add("bg-light", "text-dark");
		}
	}

	function computeDirty() {
		const now = {
			companyId: getV(companyIdEl),
			zipCode: getV(zipCodeEl),
			doName: getV(doNameEl),
			siName: getV(siNameEl),
			guName: getV(guNameEl),
			roadAddress: getV(roadAddressEl),
			detailAddress: getV(detailAddressEl),

			customerName: getV(customerNameEl),
			onsiteContact: getV(onsiteContactEl),
			productName: getV(productNameEl),
			productSize: getV(productSizeEl),
			productColor: getV(productColorEl),
			productOptions: getV(productOptionsEl),

			applicantName: getV(applicantNameEl),
			applicantPhone: getV(applicantPhoneEl),
			applicantEmail: getV(applicantEmailEl),
			purchaseDate: getV(purchaseDateEl),
			billingTarget: getV(billingTargetEl),

			adminMemo: getV(adminMemoEl),
			subject: getV(subjectInputEl),

			price: getV(priceEl),
			paymentCollected: getV(paymentCollectedEl),
			status: getV(statusEl),
			assignedHandlerId: getV(assignedHandlerEl)
		};

		let dirty = false;

		for (const key of Object.keys(initial)) {
			if ((initial[key] || "") !== (now[key] || "")) {
				dirty = true;
				break;
			}
		}

		if (!dirty && deletedRequestImageIds.length > 0) dirty = true;
		if (!dirty && deletedRequestVideoIds.length > 0) dirty = true;
		if (!dirty && newImagesInput?.files?.length > 0) dirty = true;
		if (!dirty && newVideosInput?.files?.length > 0) dirty = true;

		setDirty(dirty);
	}

	setDirty(false);
	syncPriceReadonly();

	function onlyDigits(v) {
		return String(v || "").replace(/\D/g, "");
	}

	function formatKoreanPhone(digits) {
		digits = onlyDigits(digits);
		if (digits.length > 11) digits = digits.slice(0, 11);
		if (digits.length <= 3) return digits;

		if (digits.startsWith("02")) {
			if (digits.length <= 5) return digits.slice(0, 2) + "-" + digits.slice(2);
			if (digits.length === 9) return digits.slice(0, 2) + "-" + digits.slice(2, 5) + "-" + digits.slice(5);
			if (digits.length >= 10) return digits.slice(0, 2) + "-" + digits.slice(2, 6) + "-" + digits.slice(6, 10);
		}

		if (digits.length === 10) return digits.slice(0, 3) + "-" + digits.slice(3, 6) + "-" + digits.slice(6);
		if (digits.length >= 11) return digits.slice(0, 3) + "-" + digits.slice(3, 7) + "-" + digits.slice(7, 11);

		return digits.slice(0, 3) + "-" + digits.slice(3);
	}

	function isValidPhoneByDigits(digits) {
		digits = onlyDigits(digits);
		if (!digits.startsWith("0")) return false;
		return digits.length >= 9 && digits.length <= 11;
	}

	function isValidEmail(value) {
		const email = String(value || "").trim();
		if (!email) return true;
		return /^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$/.test(email);
	}

	if (onsiteContactEl) {
		onsiteContactEl.addEventListener("input", function() {
			onsiteContactEl.value = formatKoreanPhone(onsiteContactEl.value);
			computeDirty();
		});
	}

	if (applicantPhoneEl) {
		applicantPhoneEl.addEventListener("input", function() {
			applicantPhoneEl.value = formatKoreanPhone(applicantPhoneEl.value);
			computeDirty();
		});
	}

	function toggleCompanySearch(open) {
		if (!companySearchWrap) return;
		companySearchOpen = open;

		if (open) {
			companySearchWrap.classList.remove("d-none");
			companyKeywordEl?.focus();
		} else {
			companySearchWrap.classList.add("d-none");
			if (companyKeywordEl) companyKeywordEl.value = "";
			if (companyResultsEl) companyResultsEl.innerHTML = "";
		}
	}

	if (companyEditBtn) {
		companyEditBtn.addEventListener("click", function() {
			toggleCompanySearch(!companySearchOpen);
		});
	}

	let companySearchTimer = null;

	function debounceCompanySearch(fn, waitMs) {
		return function(...args) {
			if (companySearchTimer) clearTimeout(companySearchTimer);
			companySearchTimer = setTimeout(() => fn.apply(null, args), waitMs);
		};
	}

	function escapeHtml(str) {
		return String(str || "")
			.replaceAll("&", "&amp;")
			.replaceAll("<", "&lt;")
			.replaceAll(">", "&gt;")
			.replaceAll('"', "&quot;")
			.replaceAll("'", "&#039;");
	}

	function resetMediaPreview() {
		if (!mediaPreviewBodyEl) return;

		mediaPreviewBodyEl.querySelectorAll("video").forEach(video => {
			try {
				video.pause();
				video.currentTime = 0;
			} catch (e) { /* ignore */ }
		});

		mediaPreviewBodyEl.innerHTML = "";
		if (mediaPreviewTitleEl) mediaPreviewTitleEl.textContent = "미리보기";
	}

	function extractMediaPayload(targetEl) {
		if (!targetEl) return null;

		let mediaEl = null;

		const tagName = String(targetEl.tagName || "").toLowerCase();
		if (tagName === "img" || tagName === "video") {
			mediaEl = targetEl;
		} else {
			mediaEl = targetEl.querySelector("img, video");
		}

		if (!mediaEl) return null;

		const mediaTagName = String(mediaEl.tagName || "").toLowerCase();
		const isVideo = mediaTagName === "video";
		const sourceEl = isVideo ? mediaEl.querySelector("source") : null;

		const url = isVideo
			? (mediaEl.currentSrc || mediaEl.getAttribute("src") || sourceEl?.getAttribute("src") || sourceEl?.src || "")
			: (mediaEl.currentSrc || mediaEl.getAttribute("src") || mediaEl.src || "");

		if (!url) return null;

		const cardEl = mediaEl.closest(
			".as-management-third-img-card, [data-video-id] .border, #as-management-third-existingResultVideos .border, #as-management-third-previewVideoList .border, .as-management-third-preview-item"
		);

		const nameEl = cardEl
			? cardEl.querySelector(".as-management-third-img-fn, .small.text-truncate")
			: null;

		return {
			type: isVideo ? "video" : "image",
			url: url,
			name: nameEl ? nameEl.textContent.trim() : (mediaEl.getAttribute("alt") || "미리보기"),
			contentType: isVideo ? normalizeVideoContentType(sourceEl?.getAttribute("type")) : ""
		};
	}

	function normalizeVideoContentType(value) {
		const type = String(value || "").trim().toLowerCase();
		return type.startsWith("video/") ? type : "";
	}

	function openMediaPreview(payload) {
		if (!payload || !mediaPreviewBodyEl || !mediaPreviewModal) return;

		resetMediaPreview();

		if (mediaPreviewTitleEl) {
			mediaPreviewTitleEl.textContent =
				payload.name || (payload.type === "video" ? "비디오 미리보기" : "이미지 미리보기");
		}

		if (payload.type === "video") {
			const video = document.createElement("video");
			video.className = "w-100 rounded";
			video.controls = true;
			video.preload = "metadata";
			video.playsInline = true;
			video.setAttribute("playsinline", "");
			video.setAttribute("webkit-playsinline", "");

			const source = document.createElement("source");
			source.src = payload.url;
			if (payload.contentType) source.type = payload.contentType;

			video.appendChild(source);
			mediaPreviewBodyEl.appendChild(video);
			mediaPreviewModal.show();

			setTimeout(function() {
				try {
					video.load();
				} catch (e) { /* ignore */ }
			}, 120);

			return;
		}

		const img = document.createElement("img");
		img.className = "img-fluid rounded d-block mx-auto";
		img.src = payload.url;
		img.alt = payload.name || "미리보기 이미지";

		mediaPreviewBodyEl.appendChild(img);
		mediaPreviewModal.show();
	}

	function bindMediaPreview(containerEl) {
		if (!containerEl) return;

		function isIgnoredTarget(target) {
			return !!target.closest(
				".as-management-third-img-remove-btn, " +
				".as-management-third-video-remove-btn, " +
				".as-management-third-img-download, " +
				".as-management-third-preview-remove, " +
				"a[download], " +
				".btn-outline-danger, " +
				".btn-danger"
			);
		}

		function openFromTarget(target) {
			const triggerEl = target.closest(
				".as-management-third-video-preview-trigger, " +
				"img.as-management-third-media-trigger, " +
				"video.as-management-third-media-trigger"
			);
			if (!triggerEl) return;

			const payload = extractMediaPayload(triggerEl);
			if (!payload) return;

			openMediaPreview(payload);
		}

		containerEl.addEventListener("pointerdown", function(e) {
			if (isIgnoredTarget(e.target)) {
				e.stopPropagation();
			}
		}, true);

		containerEl.addEventListener("click", function(e) {
			if (isIgnoredTarget(e.target)) {
				e.preventDefault();
				e.stopPropagation();
				return;
			}

			const triggerEl = e.target.closest(
				".as-management-third-video-preview-trigger, " +
				"img.as-management-third-media-trigger, " +
				"video.as-management-third-media-trigger"
			);
			if (!triggerEl) return;
			// 모바일에서는 video 기본 콘트롤이 재생을 담당하도록 클릭을 가로채지 않는다.
			if (e.target.closest("video[controls]")) return;

			e.preventDefault();
			e.stopPropagation();

			openFromTarget(triggerEl);
		});

		containerEl.addEventListener("keydown", function(e) {
			const triggerEl = e.target.closest(".as-management-third-video-preview-trigger");
			if (!triggerEl) return;

			if (e.key !== "Enter" && e.key !== " ") return;

			e.preventDefault();
			e.stopPropagation();

			openFromTarget(triggerEl);
		});
	}

	async function searchCompanies(keyword) {
		if (!companyResultsEl) return;

		const kw = String(keyword || "").trim();
		if (!kw) {
			companyResultsEl.innerHTML = "";
			return;
		}

		companyResultsEl.innerHTML = `<div class="list-group-item text-muted small">검색 중...</div>`;

		try {
			const url = `/management/api/companies/search?keyword=${encodeURIComponent(kw)}&limit=30`;
			const res = await fetch(url, { method: "GET" });
			if (!res.ok) throw new Error("search failed");
			const list = await res.json();

			if (!Array.isArray(list) || list.length === 0) {
				companyResultsEl.innerHTML = `<div class="list-group-item text-muted small">검색 결과가 없습니다.</div>`;
				return;
			}

			companyResultsEl.innerHTML = list.map(item => {
				const disabled = item.hasRepresentative === false;
				const cls = disabled
					? "as-management-third-company-item as-management-third-company-disabled"
					: "as-management-third-company-item";

				const name = escapeHtml(item.companyName || "-");
				const rep = escapeHtml(item.representativeName || "(대표 없음)");
				const addr = escapeHtml(item.address || "-");
				const hint = disabled
					? `<div class="as-management-third-company-addr text-danger">대표(CUSTOMER_REPRESENTATIVE)가 없어 선택할 수 없습니다.</div>`
					: "";

				return `
                    <button type="button"
                            class="${cls}"
                            ${disabled ? "disabled" : ""}
                            data-company-id="${item.companyId}"
                            data-company-name="${name}"
                            data-rep-name="${rep}">
                        <div class="as-management-third-company-title">
                            <div class="as-management-third-company-name">${name}</div>
                            <div class="as-management-third-company-rep">${rep}</div>
                        </div>
                        <div class="as-management-third-company-addr">${addr}</div>
                        ${hint}
                    </button>
                `;
			}).join("");
		} catch (e) {
			companyResultsEl.innerHTML = `<div class="list-group-item text-danger small">검색 중 오류가 발생했습니다.</div>`;
		}
	}

	const debouncedSearch = debounceCompanySearch(searchCompanies, 250);

	if (companyKeywordEl) {
		companyKeywordEl.addEventListener("input", function() {
			debouncedSearch(companyKeywordEl.value);
		});
	}

	if (companyResultsEl) {
		companyResultsEl.addEventListener("click", function(e) {
			const btn = e.target.closest("button[data-company-id]");
			if (!btn) return;

			const companyId = String(btn.getAttribute("data-company-id") || "").trim();
			const companyName = String(btn.getAttribute("data-company-name") || "").trim();
			const repName = String(btn.getAttribute("data-rep-name") || "").trim();

			if (!companyId) return;

			if (companyIdEl) companyIdEl.value = companyId;
			if (companyNameDisplay) companyNameDisplay.value = companyName || "-";
			if (requestedByNameDisplay) requestedByNameDisplay.value = repName || "-";

			toggleCompanySearch(false);
			computeDirty();
		});
	}

	let addressModal = null;
	try {
		if (window.bootstrap && addressModalEl) {
			addressModal = new bootstrap.Modal(addressModalEl);
		}
	} catch (e) {
		addressModal = null;
	}

	let mediaPreviewModal = null;
	try {
		if (window.bootstrap && mediaPreviewModalEl) {
			mediaPreviewModal = new bootstrap.Modal(mediaPreviewModalEl);
		}
	} catch (e) {
		mediaPreviewModal = null;
	}

	function openAddressModal() {
		if (modalZip) modalZip.value = getV(zipCodeEl);
		if (modalDo) modalDo.value = getV(doNameEl);
		if (modalSi) modalSi.value = getV(siNameEl);
		if (modalGu) modalGu.value = getV(guNameEl);
		if (modalRoad) modalRoad.value = getV(roadAddressEl);
		if (modalDetail) modalDetail.value = getV(detailAddressEl);

		if (addressModal) addressModal.show();
		else alert("주소 모달을 열 수 없습니다.");
	}

	if (addressEditBtn) {
		addressEditBtn.addEventListener("click", openAddressModal);
	}

	if (addressSearchBtn) {
		addressSearchBtn.addEventListener("click", function() {
			if (!window.daum || !window.daum.Postcode) {
				alert("Daum 우편번호 스크립트를 불러오지 못했습니다.");
				return;
			}

			new daum.Postcode({
				oncomplete: function(data) {
					const fullRoadAddr = data.roadAddress || "";
					const zonecode = data.zonecode || "";

					const addrParts = fullRoadAddr.split(" ");
					const doName = addrParts[0] || "";
					let siName = "";
					let guName = "";

					if (addrParts.length >= 2) {
						if (addrParts[1].endsWith("시") || addrParts[1].endsWith("군")) {
							siName = addrParts[1];
							guName = addrParts[2] || "";
						} else {
							siName = "";
							guName = addrParts[1] || "";
						}
					}

					if (modalZip) modalZip.value = zonecode;
					if (modalDo) modalDo.value = doName;
					if (modalSi) modalSi.value = siName;
					if (modalGu) modalGu.value = guName;
					if (modalRoad) modalRoad.value = fullRoadAddr;
				}
			}).open();
		});
	}

	if (addressConfirmBtn) {
		addressConfirmBtn.addEventListener("click", function() {
			if (zipCodeEl) zipCodeEl.value = getV(modalZip);
			if (doNameEl) doNameEl.value = getV(modalDo);
			if (siNameEl) siNameEl.value = getV(modalSi);
			if (guNameEl) guNameEl.value = getV(modalGu);
			if (roadAddressEl) roadAddressEl.value = getV(modalRoad);
			if (detailAddressEl) detailAddressEl.value = getV(modalDetail);

			if (addressModal) addressModal.hide();
			computeDirty();
		});
	}

	const SUBJECT_MAP = {
		"상부장": ["도어 파손", "도어 스크레치", "도어 휘어짐", "도어 변색", "도어 단차 불량", "도어 마감 불량",
			"손잡이 불량", "바디 변색", "바디 스크래치", "바디 파손", "개폐 불량", "경첩 불량",
			"LED 점등 불량", "오출고", "기타 사유"],
		"슬라이드장": ["도어 파손", "도어 스크레치", "도어 변색", "도어 간격 불량", "바디 변색", "바디 스크레치",
			"바디 파손", "개폐불량", "댐퍼불량", "손잡이 불량", "LED 점등 불량", "오출고", "기타 사유"],
		"플랩장": ["도어 파손", "도어 스크레치", "도어 변색", "도어 단차 불량", "유압 불량", "바디 변색",
			"바디 스크래치", "바디 파손", "개폐 불량", "경첩 불량", "LED 점등 불량", "오출고", "기타 사유"],
		"하부장": ["도어 단차 불량", "서랍 개폐불량", "도어 마감 불량", "오출고", "기타 사유"],
		"거울": ["테두리 도장 불량", "유리 스크레치", "유리 파손", "유리 변색", "LED 점등 불량", "오출고", "기타 사유"]
	};

	function resetSymptomSelect() {
		if (!subjectSymptomEl) return;
		subjectSymptomEl.innerHTML = `<option value="">== 증상 선택 ==</option>`;
		subjectSymptomEl.disabled = true;
	}

	function fillSymptomSelect(category) {
		resetSymptomSelect();
		if (!category || !SUBJECT_MAP[category] || !subjectSymptomEl) return;

		Array.from(new Set(SUBJECT_MAP[category])).forEach(symptom => {
			const opt = document.createElement("option");
			opt.value = `${category} - ${symptom}`;
			opt.textContent = symptom;
			subjectSymptomEl.appendChild(opt);
		});

		subjectSymptomEl.disabled = false;
	}

	function initSubjectSelectFromCurrent() {
		const cur = getV(subjectInputEl);
		if (!cur || !subjectCategoryEl || !subjectSymptomEl) return;

		const parts = cur.split(" - ");
		if (parts.length !== 2) return;

		const category = parts[0].trim();
		const symptom = parts[1].trim();

		subjectCategoryEl.value = category;
		fillSymptomSelect(category);
		subjectSymptomEl.value = `${category} - ${symptom}`;
	}

	if (subjectCategoryEl && subjectSymptomEl) {
		resetSymptomSelect();
		initSubjectSelectFromCurrent();

		subjectCategoryEl.addEventListener("change", function() {
			fillSymptomSelect(subjectCategoryEl.value);
		});

		subjectSymptomEl.addEventListener("change", function() {
			const v = getV(subjectSymptomEl);
			if (!v) return;

			if (subjectInputEl) subjectInputEl.value = v;
			computeDirty();
		});
	}

	function syncDeletedImageIds() {
		if (deleteRequestImageIdsEl) {
			deleteRequestImageIdsEl.value = deletedRequestImageIds.join(",");
		}
	}

	function syncDeletedVideoIds() {
		if (deleteRequestVideoIdsEl) {
			deleteRequestVideoIdsEl.value = deletedRequestVideoIds.join(",");
		}
	}

	if (existingImagesWrap) {
		existingImagesWrap.addEventListener("click", function(e) {
			const btn = e.target.closest(".as-management-third-img-remove-btn");
			if (!btn) return;

			e.preventDefault();
			e.stopPropagation();

			const cardCol = btn.closest("[data-image-id]");
			if (!cardCol) return;

			const id = String(cardCol.getAttribute("data-image-id") || "").trim();
			if (!id) return;

			const numId = Number(id);
			if (!deletedRequestImageIds.includes(numId)) {
				deletedRequestImageIds.push(numId);
			}

			syncDeletedImageIds();
			cardCol.remove();
			computeDirty();
		});
	}

	if (existingVideosWrap) {
		existingVideosWrap.addEventListener("click", function(e) {
			const btn = e.target.closest(".as-management-third-video-remove-btn");
			if (!btn) return;

			e.preventDefault();
			e.stopPropagation();

			const cardCol = btn.closest("[data-video-id]");
			if (!cardCol) return;

			const id = String(cardCol.getAttribute("data-video-id") || "").trim();
			if (!id) return;

			const numId = Number(id);
			if (!deletedRequestVideoIds.includes(numId)) {
				deletedRequestVideoIds.push(numId);
			}

			syncDeletedVideoIds();
			cardCol.remove();
			computeDirty();
		});
	}

	function removeFileFromInput(inputEl, indexToRemove, callback) {
		if (!inputEl) return;

		const dt = new DataTransfer();
		Array.from(inputEl.files || []).forEach((file, idx) => {
			if (idx !== indexToRemove) dt.items.add(file);
		});

		inputEl.files = dt.files;

		if (typeof callback === "function") callback();
		computeDirty();
	}

	function renderImagePreview() {
		if (!previewList || !newImagesInput) return;
		previewList.innerHTML = "";

		const files = Array.from(newImagesInput.files || []);
		if (files.length === 0) {
			previewList.innerHTML = `<div class="text-muted small">추가 업로드된 이미지가 없습니다.</div>`;
			return;
		}

		files.forEach((file, idx) => {
			const reader = new FileReader();

			reader.onload = function(ev) {
				const item = document.createElement("div");
				item.className = "as-management-third-preview-item";

				const img = document.createElement("img");
				img.src = ev.target.result;
				img.className = "as-management-third-media-trigger";
				img.title = "클릭하여 미리보기";
				img.alt = file.name || "preview image";

				const removeBtn = document.createElement("button");
				removeBtn.type = "button";
				removeBtn.className = "as-management-third-preview-remove";
				removeBtn.textContent = "×";
				removeBtn.addEventListener("click", function(e) {
					e.preventDefault();
					e.stopPropagation();
					removeFileFromInput(newImagesInput, idx, renderImagePreview);
				});

				item.appendChild(img);
				item.appendChild(removeBtn);
				previewList.appendChild(item);
			};

			reader.readAsDataURL(file);
		});
	}

	function renderVideoPreview() {
		if (!previewVideoList || !newVideosInput) return;
		previewVideoList.innerHTML = "";

		const files = Array.from(newVideosInput.files || []);
		if (files.length === 0) {
			previewVideoList.innerHTML = `<div class="col-12"><div class="text-muted small">추가 업로드된 비디오가 없습니다.</div></div>`;
			return;
		}

		files.forEach((file, idx) => {
			const url = URL.createObjectURL(file);

			const col = document.createElement("div");
			col.className = "col-md-6";

			const box = document.createElement("div");
			box.className = "as-management-third-video-card border rounded p-2 h-100 bg-light";

			const previewTrigger = document.createElement("div");
			previewTrigger.className = "as-management-third-video-preview-trigger";
			previewTrigger.setAttribute("role", "button");
			previewTrigger.setAttribute("tabindex", "0");
			previewTrigger.setAttribute("title", "클릭하여 미리보기");
			previewTrigger.setAttribute("aria-label", "비디오 미리보기 열기");

			const video = document.createElement("video");
			video.className = "w-100 rounded mb-2 as-management-third-media-trigger";
			video.preload = "metadata";
			video.controls = true;
			video.playsInline = true;
			video.setAttribute("playsinline", "");
			video.setAttribute("webkit-playsinline", "");
			video.src = url;

			const previewBadge = document.createElement("button");
			previewBadge.type = "button";
			previewBadge.className = "as-management-third-video-preview-badge";
			previewBadge.textContent = "큰 화면";

			const name = document.createElement("div");
			name.className = "small text-truncate";
			name.textContent = file.name;

			const removeBtn = document.createElement("button");
			removeBtn.type = "button";
			removeBtn.className = "btn btn-sm btn-outline-danger mt-2";
			removeBtn.textContent = "제거";
			removeBtn.addEventListener("click", function(e) {
				e.preventDefault();
				e.stopPropagation();
				URL.revokeObjectURL(url);
				removeFileFromInput(newVideosInput, idx, renderVideoPreview);
			});

			previewTrigger.appendChild(video);
			previewTrigger.appendChild(previewBadge);
			box.appendChild(previewTrigger);
			box.appendChild(name);
			box.appendChild(removeBtn);
			col.appendChild(box);
			previewVideoList.appendChild(col);
		});
	}

	if (uploadBtn && newImagesInput) {
		uploadBtn.addEventListener("click", function() {
			newImagesInput.click();
		});
	}

	if (newImagesInput) {
		newImagesInput.addEventListener("change", function() {
			renderImagePreview();
			computeDirty();
		});
	}

	if (uploadVideoBtn && newVideosInput) {
		uploadVideoBtn.addEventListener("click", function() {
			newVideosInput.click();
		});
	}

	if (newVideosInput) {
		newVideosInput.addEventListener("change", function() {
			renderVideoPreview();
			computeDirty();
		});
	}

	renderImagePreview();
	renderVideoPreview();

	bindMediaPreview(existingImagesWrap);
	bindMediaPreview(existingVideosWrap);
	bindMediaPreview(existingResultImagesWrap);
	bindMediaPreview(existingResultVideosWrap);
	bindMediaPreview(previewList);
	bindMediaPreview(previewVideoList);

	// iOS Safari를 포함한 모바일 브라우저가 인라인 재생 UI와 메타데이터를 즉시 구성하도록 보정한다.
	document.querySelectorAll(".as-management-third-video-preview-trigger video").forEach(video => {
		video.controls = true;
		video.playsInline = true;
		video.setAttribute("playsinline", "");
		video.setAttribute("webkit-playsinline", "");
		try { video.load(); } catch (e) { /* ignore */ }
	});

	if (mediaPreviewModalEl) {
		mediaPreviewModalEl.addEventListener("hidden.bs.modal", resetMediaPreview);
	}

	const watchEls = [
		companyIdEl,
		zipCodeEl, doNameEl, siNameEl, guNameEl, roadAddressEl, detailAddressEl,
		customerNameEl, onsiteContactEl, productNameEl, productSizeEl, productColorEl, productOptionsEl,
		applicantNameEl, applicantPhoneEl, applicantEmailEl, purchaseDateEl, billingTargetEl,
		adminMemoEl,
		subjectInputEl,
		priceEl, paymentCollectedEl, statusEl, assignedHandlerEl
	];

	watchEls.forEach(el => {
		if (!el) return;
		el.addEventListener("input", computeDirty);
		el.addEventListener("change", computeDirty);
	});

	if (statusEl) {
		statusEl.addEventListener("change", function() {
			syncPriceReadonly();
			computeDirty();
		});
	}

	form.addEventListener("submit", function(e) {
		if (saveBtn && saveBtn.disabled) {
			e.preventDefault();
			return;
		}

		if (assignedHandlerEl && !getV(assignedHandlerEl)) {
			e.preventDefault();
			alert("담당자를 선택해 주세요.");
			assignedHandlerEl.focus();
			return;
		}

		if (statusEl && !getV(statusEl)) {
			e.preventDefault();
			alert("AS 상태를 선택해 주세요.");
			statusEl.focus();
			return;
		}

		if (onsiteContactEl) {
			const digits = onlyDigits(onsiteContactEl.value);
			if (digits && !isValidPhoneByDigits(digits)) {
				e.preventDefault();
				alert("현장 연락처 형식이 올바르지 않습니다.\n예) 0311234567 / 01012345678");
				onsiteContactEl.focus();
				return;
			}
			onsiteContactEl.value = formatKoreanPhone(digits);
		}

		if (applicantPhoneEl) {
			const digits = onlyDigits(applicantPhoneEl.value);
			if (digits && !isValidPhoneByDigits(digits)) {
				e.preventDefault();
				alert("접수 담당자 연락처 형식이 올바르지 않습니다.\n예) 0311234567 / 01012345678");
				applicantPhoneEl.focus();
				return;
			}
			applicantPhoneEl.value = formatKoreanPhone(digits);
		}

		if (applicantEmailEl && !isValidEmail(applicantEmailEl.value)) {
			e.preventDefault();
			alert("접수 담당자 이메일 형식이 올바르지 않습니다.");
			applicantEmailEl.focus();
			return;
		}
	});

	if (deleteBtn && deleteForm) {
		deleteBtn.addEventListener("click", function() {
			const ok = confirm("등록한 일정 및 첨부파일(이미지/비디오)까지 모두 삭제됩니다.\n정말 삭제하시겠습니까?");
			if (!ok) return;
			deleteForm.submit();
		});
	}
});
