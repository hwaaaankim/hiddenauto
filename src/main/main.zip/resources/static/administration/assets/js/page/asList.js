(function() {
	'use strict';

	const selectedFromServer = window.__AS_SELECTED__ || {};

	function resetSelect(selectEl, placeholderText) {
		if (!selectEl) return;
		selectEl.innerHTML = '';
		const opt = document.createElement('option');
		opt.value = '';
		opt.textContent = placeholderText || '전체';
		selectEl.appendChild(opt);
	}

	function show(el) { if (el) el.style.display = ''; }
	function hide(el) { if (el) el.style.display = 'none'; }

	async function fetchJson(url) {
		const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
		if (!res.ok) throw new Error('API 요청 실패: ' + url);
		return res.json();
	}

	function fillOptions(selectEl, items, selectedId) {
		if (!selectEl) return;
		(items || []).forEach(item => {
			const opt = document.createElement('option');
			opt.value = String(item.id);
			opt.textContent = item.name;
			if (selectedId != null && String(selectedId) === String(item.id)) {
				opt.selected = true;
			}
			selectEl.appendChild(opt);
		});
	}

	function selectedOptionText(selectEl) {
		if (!selectEl || !selectEl.value) return '';
		const opt = selectEl.options && selectEl.selectedIndex >= 0
			? selectEl.options[selectEl.selectedIndex]
			: null;
		return opt ? String(opt.textContent || '').trim() : '';
	}

	function createRegionController(config, initialSelected) {
		const provinceSelect = document.getElementById(config.provinceSelectId);
		const childWrapper = document.getElementById(config.childWrapperId);
		const childLabel = document.getElementById(config.childLabelId);
		const citySelect = document.getElementById(config.citySelectId);
		const districtDirectSelect = document.getElementById(config.districtDirectSelectId);
		const districtWrapper = document.getElementById(config.districtWrapperId);
		const districtSelect = document.getElementById(config.districtSelectId);
		const districtHidden = document.getElementById(config.districtHiddenId);

		const selected = {
			cityId: initialSelected?.cityId ?? null,
			districtId: initialSelected?.districtId ?? null
		};

		function setDistrictHidden(v) {
			if (!districtHidden) return;
			districtHidden.value = (v == null) ? '' : String(v);
		}

		function hideAllRegionControls() {
			hide(childWrapper);
			hide(citySelect);
			hide(districtDirectSelect);
			hide(districtWrapper);
			hide(districtSelect);
		}

		async function onCityChange(isInit) {
			const cityId = citySelect ? citySelect.value : '';

			resetSelect(districtSelect, '전체');
			hide(districtWrapper);
			hide(districtSelect);

			if (!cityId) {
				setDistrictHidden('');
				return;
			}

			const items = await fetchJson(`/api/regions/cities/${encodeURIComponent(cityId)}/districts`);
			show(districtWrapper);
			show(districtSelect);
			fillOptions(districtSelect, items, isInit ? selected.districtId : null);

			if (isInit && selected.districtId) {
				setDistrictHidden(selected.districtId);
			} else {
				setDistrictHidden(districtSelect?.value || '');
			}
		}

		async function onProvinceChange(isInit) {
			if (!provinceSelect) return;

			const provinceId = provinceSelect.value;

			resetSelect(citySelect, '전체');
			resetSelect(districtDirectSelect, '전체');
			resetSelect(districtSelect, '전체');
			hideAllRegionControls();

			if (!provinceId) {
				setDistrictHidden('');
				return;
			}

			const data = await fetchJson(`/api/regions/provinces/${encodeURIComponent(provinceId)}/children`);
			show(childWrapper);

			if (data.type === 'CITY') {
				if (childLabel) childLabel.textContent = '시/군';
				show(citySelect);
				fillOptions(citySelect, data.items, isInit ? selected.cityId : null);
				hide(districtDirectSelect);

				if (isInit && selected.cityId) {
					await onCityChange(true);
				} else {
					hide(districtWrapper);
					hide(districtSelect);
					setDistrictHidden('');
				}
			} else if (data.type === 'DISTRICT') {
				if (childLabel) childLabel.textContent = '구/군';
				hide(citySelect);
				show(districtDirectSelect);
				fillOptions(districtDirectSelect, data.items, isInit ? selected.districtId : null);
				hide(districtWrapper);
				hide(districtSelect);

				if (isInit && selected.districtId) {
					setDistrictHidden(selected.districtId);
				} else {
					setDistrictHidden(districtDirectSelect?.value || '');
				}
			}
		}

		function bind() {
			if (!provinceSelect) return;

			provinceSelect.addEventListener('change', () => {
				selected.cityId = null;
				selected.districtId = null;
				setDistrictHidden('');
				onProvinceChange(false).catch(console.error);
			});

			if (citySelect) {
				citySelect.addEventListener('change', () => {
					selected.districtId = null;
					setDistrictHidden('');
					onCityChange(false).catch(console.error);
				});
			}

			if (districtDirectSelect) {
				districtDirectSelect.addEventListener('change', () => {
					const v = districtDirectSelect.value;
					selected.districtId = v ? Number(v) : null;
					setDistrictHidden(v || '');
				});
			}

			if (districtSelect) {
				districtSelect.addEventListener('change', () => {
					const v = districtSelect.value;
					selected.districtId = v ? Number(v) : null;
					setDistrictHidden(v || '');
				});
			}
		}

		function getRegionLabel() {
			if (!provinceSelect || !provinceSelect.value) return '전체';

			const parts = [];
			const provinceText = selectedOptionText(provinceSelect);
			const cityText = selectedOptionText(citySelect);
			const directDistrictText = selectedOptionText(districtDirectSelect);
			const districtText = selectedOptionText(districtSelect);

			if (provinceText) parts.push(provinceText);
			if (citySelect?.value && cityText) parts.push(cityText);
			if (districtSelect?.value && districtText) {
				parts.push(districtText);
			} else if (districtDirectSelect?.value && directDistrictText) {
				parts.push(directDistrictText);
			}

			return parts.length > 0 ? parts.join(' ') : '전체';
		}

		async function init() {
			if (!provinceSelect) return;
			bind();
			await onProvinceChange(true);
		}

		return {
			init,
			getRegionLabel
		};
	}

	const topRegionController = createRegionController({
		provinceSelectId: 'as-province-select',
		childWrapperId: 'as-child-wrapper',
		childLabelId: 'as-child-label',
		citySelectId: 'as-city-select',
		districtDirectSelectId: 'as-district-direct-select',
		districtWrapperId: 'as-district-wrapper',
		districtSelectId: 'as-district-select',
		districtHiddenId: 'as-district-hidden'
	}, selectedFromServer);

	const modalRegionController = createRegionController({
		provinceSelectId: 'as-filter-modal-province-select',
		childWrapperId: 'as-filter-modal-child-wrapper',
		childLabelId: 'as-filter-modal-child-label',
		citySelectId: 'as-filter-modal-city-select',
		districtDirectSelectId: 'as-filter-modal-district-direct-select',
		districtWrapperId: 'as-filter-modal-district-wrapper',
		districtSelectId: 'as-filter-modal-district-select',
		districtHiddenId: 'as-filter-modal-district-hidden'
	}, selectedFromServer);

	const topFilterArea = document.getElementById('asList-top-filter-area');
	const topFilterForm = document.getElementById('asList-top-filter-form');
	const filterSummary = document.getElementById('asList-active-filter-summary');
	const filterChips = document.getElementById('asList-active-filter-chips');
	const floatingFilterButton = document.getElementById('asList-floating-filter-button');
	const floatingFilterCount = document.getElementById('asList-floating-filter-count');
	const filterResetButton = document.getElementById('asList-filter-reset-button');
	const filterModalEl = document.getElementById('asList-filter-modal');

	function isMobileFilterLayout() {
		return window.matchMedia('(max-width: 991.98px)').matches;
	}

	function getFormControl(form, name) {
		return form ? form.querySelector(`[name="${name}"]`) : null;
	}

	function getSelectedText(selectEl, fallback) {
		if (!selectEl) return fallback || '';
		const opt = selectEl.options && selectEl.selectedIndex >= 0
			? selectEl.options[selectEl.selectedIndex]
			: null;
		return opt ? String(opt.textContent || '').trim() : (fallback || '');
	}

	function addFilterChip(label, value) {
		if (!filterChips) return;
		const chip = document.createElement('span');
		chip.className = 'asList-filter-chip';

		const strong = document.createElement('strong');
		strong.textContent = label;
		chip.appendChild(strong);
		chip.appendChild(document.createTextNode(value || '-'));
		filterChips.appendChild(chip);
	}

	function sortLabelFromForm(form) {
		if (!form) return '';
		const configs = [
			['idSort', 'ID'],
			['statusSort', '상태'],
			['addressSort', '주소'],
			['scheduledDateSort', '방문예정일'],
			['visitTimeSort', '방문예정시간']
		];

		for (const [name, label] of configs) {
			const value = String(getFormControl(form, name)?.value || '').toLowerCase();
			if (value === 'asc') return `${label} ↑`;
			if (value === 'desc') return `${label} ↓`;
		}
		return '';
	}

	function getActiveFilterCount(form) {
		if (!form) return 0;
		let count = 0;
		if (getFormControl(form, 'status')?.value) count++;
		if (getFormControl(form, 'dateType')?.value && getFormControl(form, 'dateType').value !== 'requested') count++;
		if (getFormControl(form, 'startDate')?.value || getFormControl(form, 'endDate')?.value) count++;
		if (getFormControl(form, 'asIdFrom')?.value || getFormControl(form, 'asIdTo')?.value) count++;
		if (String(getFormControl(form, 'companyKeyword')?.value || '').trim()) count++;
		if (getFormControl(form, 'provinceId')?.value) count++;
		return count;
	}

	function renderCurrentFilterSummary() {
		if (!topFilterForm || !filterChips) return;
		filterChips.innerHTML = '';

		const statusEl = getFormControl(topFilterForm, 'status');
		const dateTypeEl = getFormControl(topFilterForm, 'dateType');
		const startDate = getFormControl(topFilterForm, 'startDate')?.value || '';
		const endDate = getFormControl(topFilterForm, 'endDate')?.value || '';
		const asIdFrom = String(getFormControl(topFilterForm, 'asIdFrom')?.value || '').trim();
		const asIdTo = String(getFormControl(topFilterForm, 'asIdTo')?.value || '').trim();
		const companyKeyword = String(getFormControl(topFilterForm, 'companyKeyword')?.value || '').trim();
		const regionLabel = topRegionController.getRegionLabel();
		const sortLabel = sortLabelFromForm(topFilterForm);

		addFilterChip('상태', statusEl?.value ? getSelectedText(statusEl, '전체') : '전체');
		addFilterChip('기준', getSelectedText(dateTypeEl, '신청일'));

		let period = '전체기간';
		if (startDate && endDate) period = `${startDate} ~ ${endDate}`;
		else if (startDate) period = `${startDate} ~`;
		else if (endDate) period = `~ ${endDate}`;
		addFilterChip('기간', period);

		let asIdRange = '전체';
		if (asIdFrom && asIdTo) asIdRange = asIdFrom === asIdTo ? asIdFrom : `${asIdFrom} ~ ${asIdTo}`;
		else if (asIdFrom) asIdRange = `${asIdFrom} 이상`;
		else if (asIdTo) asIdRange = `${asIdTo} 이하`;
		addFilterChip('AS ID', asIdRange);

		addFilterChip('업체', companyKeyword || '전체');
		addFilterChip('지역', regionLabel || '전체');
		if (sortLabel) addFilterChip('정렬', sortLabel);

		const activeCount = getActiveFilterCount(topFilterForm);
		if (floatingFilterButton) {
			floatingFilterButton.classList.toggle('has-active-filters', activeCount > 0);
		}
		if (floatingFilterCount) {
			floatingFilterCount.textContent = String(activeCount);
		}
	}

	let floatingRaf = null;
	function updateFloatingFilterVisibility() {
		if (!floatingFilterButton || !filterSummary) return;

		if (isMobileFilterLayout()) {
			floatingFilterButton.classList.add('is-visible');
			filterSummary.classList.add('is-visible');
			return;
		}

		if (!topFilterArea) {
			floatingFilterButton.classList.add('is-visible');
			filterSummary.classList.add('is-visible');
			return;
		}

		const rect = topFilterArea.getBoundingClientRect();
		const headerSafeLine = 72;
		const filterIsGone = rect.bottom <= headerSafeLine;

		floatingFilterButton.classList.toggle('is-visible', filterIsGone);
		filterSummary.classList.toggle('is-visible', filterIsGone);
	}

	function requestFloatingFilterVisibilityUpdate() {
		if (floatingRaf) return;
		floatingRaf = window.requestAnimationFrame(() => {
			floatingRaf = null;
			updateFloatingFilterVisibility();
		});
	}

	function bindFilterUx() {
		window.addEventListener('scroll', requestFloatingFilterVisibilityUpdate, { passive: true });
		window.addEventListener('resize', requestFloatingFilterVisibilityUpdate);

		if (filterResetButton) {
			filterResetButton.addEventListener('click', () => {
				window.location.href = '/team/asList';
			});
		}

		if (filterModalEl) {
			filterModalEl.addEventListener('shown.bs.modal', () => {
				const first = filterModalEl.querySelector('select, input:not([type="hidden"])');
				if (first && typeof first.focus === 'function') first.focus({ preventScroll: true });
			});
		}

		updateFloatingFilterVisibility();
	}

	const modalEl = document.getElementById('asList-second-complete-modal');
	const formEl = document.getElementById('asList-second-complete-form');
	const alertEl = document.getElementById('asList-second-modal-alert');

	const btnUpload = document.getElementById('asList-second-btn-upload');
	const btnCamera = document.getElementById('asList-second-btn-camera');

	const fileInput = document.getElementById('asList-second-file-input');
	const imageList = document.getElementById('asList-second-image-list');
	const requestVideoList = document.getElementById('asList-second-request-videos');
	const btnComplete = document.getElementById('asList-second-btn-complete');

	const field = {
		company: document.getElementById('asList-second-field-company'),
		requester: document.getElementById('asList-second-field-requester'),
		address: document.getElementById('asList-second-field-address'),
		reason: document.getElementById('asList-second-field-reason'),
		adminMemo: document.getElementById('asList-second-field-adminMemo'),
		handlerMemo: document.getElementById('asList-second-field-handlerMemo'),
		visitPlannedTime: document.getElementById('asList-second-field-visitPlannedTime'),
		productName: document.getElementById('asList-second-field-productName'),
		productSize: document.getElementById('asList-second-field-productSize'),
		productColor: document.getElementById('asList-second-field-productColor'),
		onsiteContact: document.getElementById('asList-second-field-onsiteContact'),
		requestedAt: document.getElementById('asList-second-field-requestedAt')
	};

	let bsModal = null;
	let currentTaskId = null;
	let currentTaskStatus = null;

	let existingResultImages = [];
	let selectedFiles = [];
	let requestVideos = [];
	let imageProcessing = false;

	function isMobile() {
		return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
	}

	function setAlert(type, msg) {
		if (!alertEl) return;
		if (!msg) {
			alertEl.className = 'alert d-none';
			alertEl.textContent = '';
			return;
		}
		alertEl.className = 'alert';
		alertEl.classList.add(type === 'danger' ? 'alert-danger' : 'alert-info');
		alertEl.textContent = msg;
		alertEl.classList.remove('d-none');
	}

	function escapeHtml(s) {
		return String(s ?? '').replace(/[&<>"']/g, (m) => ({
			'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
		}[m]));
	}

	function setText(el, v) {
		if (!el) return;
		el.textContent = (v == null || String(v).trim() === '') ? '-' : String(v);
	}

	function syncFileInputFromSelectedFiles() {
		if (!fileInput) return;
		const dt = new DataTransfer();
		selectedFiles.forEach(f => dt.items.add(f));
		fileInput.files = dt.files;
	}

	function updateCompleteButtonState() {
		if (btnComplete) {
			if (currentTaskStatus !== 'IN_PROGRESS' || imageProcessing) {
				btnComplete.disabled = true;
				return;
			}
		}

		const total = (existingResultImages?.length || 0) + (selectedFiles?.length || 0);
		if (btnComplete) btnComplete.disabled = total <= 0;
	}

	function renderImages() {
		if (!imageList) return;
		imageList.innerHTML = '';

		(existingResultImages || []).forEach(img => {
			const col = document.createElement('div');
			col.className = 'col-6 col-sm-4 col-md-3';

			col.innerHTML = `
                <div class="border rounded p-2 position-relative asList-second-image-card">
                    <button type="button"
                            class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1 asList-second-btn-remove-existing"
                            data-image-id="${img.id}"
                            title="삭제">×</button>
                    <img src="${escapeHtml(img.url)}" class="img-fluid rounded mb-2" style="max-height: 140px; width: 100%; object-fit: cover;">
                    <div class="small text-truncate text-muted">${escapeHtml(img.filename || '')}</div>
                </div>
            `;
			imageList.appendChild(col);
		});

		(selectedFiles || []).forEach((file, idx) => {
			const col = document.createElement('div');
			col.className = 'col-6 col-sm-4 col-md-3';

			const url = URL.createObjectURL(file);
			col.innerHTML = `
                <div class="border rounded p-2 position-relative asList-second-image-card">
                    <button type="button"
                            class="btn btn-sm btn-dark position-absolute top-0 end-0 m-1 asList-second-btn-remove-new"
                            data-file-idx="${idx}"
                            title="제거">×</button>
                    <img src="${escapeHtml(url)}" class="img-fluid rounded mb-2" style="max-height: 140px; width: 100%; object-fit: cover;">
                    <div class="small text-truncate text-muted">${escapeHtml(file.name)}</div>
                </div>
            `;
			imageList.appendChild(col);
		});

		updateCompleteButtonState();
	}

	function normalizeVideoType(contentType) {
		const value = String(contentType || '').trim().toLowerCase();
		return value.startsWith('video/') ? value : '';
	}

	function renderRequestVideos() {
		if (!requestVideoList) return;
		requestVideoList.innerHTML = '';

		if (!requestVideos.length) {
			requestVideoList.innerHTML = '<div class="col-12 text-muted small">등록된 동영상이 없습니다.</div>';
			return;
		}

		requestVideos.forEach(item => {
			const col = document.createElement('div');
			col.className = 'col-12 col-md-6';
			const type = normalizeVideoType(item.contentType);
			const sourceType = type ? ` type="${escapeHtml(type)}"` : '';
			col.innerHTML = `
				<div class="asList-second-video-card border rounded overflow-hidden bg-dark">
					<video class="d-block w-100" controls preload="metadata" playsinline webkit-playsinline>
						<source src="${escapeHtml(item.url || '')}"${sourceType}>
						사용 중인 브라우저에서 동영상 재생을 지원하지 않습니다.
					</video>
					<div class="d-flex align-items-center justify-content-between gap-2 p-2 bg-white">
						<span class="small text-muted text-truncate">${escapeHtml(item.filename || '동영상')}</span>
						<a class="btn btn-sm btn-light border" href="${escapeHtml(item.url || '')}" download aria-label="동영상 다운로드">다운로드</a>
					</div>
				</div>`;
			requestVideoList.appendChild(col);
		});
	}

	async function deleteExistingImage(imageId) {
		if (currentTaskStatus !== 'IN_PROGRESS') {
			alert('진행중 건에 대해서만 가능합니다.');
			return;
		}

		const res = await fetch(`/team/asImageDelete/${imageId}`, { method: 'DELETE' });
		if (!res.ok) throw new Error('이미지 삭제 실패');
		existingResultImages = existingResultImages.filter(x => String(x.id) !== String(imageId));
		renderImages();
	}

	function removeNewFileByIndex(idx) {
		if (currentTaskStatus !== 'IN_PROGRESS') {
			alert('진행중 건에 대해서만 가능합니다.');
			return;
		}

		if (imageProcessing) {
			alert('이미지 변환이 끝난 뒤 제거해 주세요.');
			return;
		}

		selectedFiles = selectedFiles.filter((_, i) => i !== idx);
		syncFileInputFromSelectedFiles();
		renderImages();
	}

	function bindImageListEvents() {
		if (!imageList) return;

		imageList.addEventListener('click', (e) => {
			const btnExisting = e.target.closest('.asList-second-btn-remove-existing');
			if (btnExisting) {
				e.preventDefault();
				e.stopPropagation();
				const imageId = btnExisting.getAttribute('data-image-id');
				if (!imageId) return;

				if (confirm('이 이미지를 삭제하시겠습니까?')) {
					deleteExistingImage(imageId).catch(err => {
						console.error(err);
						alert('삭제 실패');
					});
				}
				return;
			}

			const btnNew = e.target.closest('.asList-second-btn-remove-new');
			if (btnNew) {
				e.preventDefault();
				e.stopPropagation();
				const idx = parseInt(btnNew.getAttribute('data-file-idx'), 10);
				if (Number.isFinite(idx)) removeNewFileByIndex(idx);
			}
		});
	}

	function setImageProcessing(value, message) {
		imageProcessing = Boolean(value);

		const uploadDisabled = imageProcessing || currentTaskStatus !== 'IN_PROGRESS';
		if (btnUpload) btnUpload.disabled = uploadDisabled;
		if (btnCamera) btnCamera.disabled = uploadDisabled;

		if (imageProcessing) {
			setAlert('info', message || '선택한 이미지를 업로드 가능한 형식으로 변환하고 있습니다.');
		}

		updateCompleteButtonState();
	}

	function bindFileInput() {
		if (!fileInput) return;

		fileInput.addEventListener('change', async () => {
			if (currentTaskStatus !== 'IN_PROGRESS') {
				fileInput.value = '';
				alert('진행중 건에 대해서만 가능합니다.');
				return;
			}

			const incoming = Array.from(fileInput.files || []);
			fileInput.value = '';
			if (incoming.length === 0) {
				syncFileInputFromSelectedFiles();
				return;
			}

			if (!window.HiddenAutoImageUpload) {
				syncFileInputFromSelectedFiles();
				alert('이미지 변환 모듈을 불러오지 못했습니다. 화면을 새로고침한 뒤 다시 시도해 주세요.');
				return;
			}

			try {
				setImageProcessing(true, '선택한 이미지를 확인하고 있습니다. HEIC/HEIF 사진은 JPEG로 변환 후 첨부됩니다.');

				const normalized = await window.HiddenAutoImageUpload.normalizeFiles(incoming, {
					jpegQuality: 0.94
				});

				selectedFiles = selectedFiles.concat(normalized.files);
				syncFileInputFromSelectedFiles();
				renderImages();

				const messages = [];
				if (normalized.converted.length > 0) {
					messages.push(`HEIC/HEIF ${normalized.converted.length}장을 JPEG로 변환했습니다.`);
				}
				if (normalized.rejected.length > 0) {
					messages.push(`이미지가 아닌 ${normalized.rejected.length}개 파일은 제외했습니다.`);
				}

				if (messages.length > 0) {
					setAlert(normalized.rejected.length > 0 ? 'danger' : 'info', messages.join(' '));
				} else {
					setAlert(null, null);
				}

			} catch (error) {
				console.error(error);
				syncFileInputFromSelectedFiles();
				setAlert('danger', error && error.message ? error.message : '이미지 변환 중 오류가 발생했습니다.');
			} finally {
				setImageProcessing(false);
			}
		});
	}

	function openFilePicker(mode) {
		if (!fileInput) return;

		if (currentTaskStatus !== 'IN_PROGRESS') {
			alert('진행중 건에 대해서만 가능합니다.');
			return;
		}

		if (imageProcessing) {
			alert('이미지 변환이 끝난 뒤 다시 선택해 주세요.');
			return;
		}

		if (mode === 'camera') {
			fileInput.setAttribute('capture', 'environment');
		} else {
			fileInput.removeAttribute('capture');
		}
		fileInput.click();
	}

	function bindUploadButtons() {
		if (btnUpload) {
			btnUpload.addEventListener('click', (e) => {
				e.preventDefault();
				e.stopPropagation();
				openFilePicker('gallery');
			});
		}

		if (btnCamera) {
			btnCamera.addEventListener('click', (e) => {
				e.preventDefault();
				e.stopPropagation();
				openFilePicker('camera');
			});
		}
	}

	function applyMobileButtonsVisibility() {
		if (isMobile()) {
			if (btnCamera) btnCamera.classList.remove('d-none');
		} else {
			if (btnCamera) btnCamera.classList.add('d-none');
		}
	}

	function lockModalIfNotInProgress() {
		if (currentTaskStatus !== 'IN_PROGRESS') {
			setAlert('danger', '진행중 건에 대해서만 가능합니다.');
			if (btnComplete) btnComplete.disabled = true;
		}
		updateCompleteButtonState();
	}

	async function loadTaskForModal(taskId) {
		setAlert(null, null);

		const data = await fetchJson(`/team/asDetailModal/${taskId}`);

		setText(field.company, data.companyName);
		setText(field.requester, data.requesterName);
		setText(field.address, data.fullAddress);
		setText(field.reason, data.reason);
		setText(field.adminMemo, data.adminMemo);
		setText(field.handlerMemo, data.handlerMemo);
		setText(field.visitPlannedTime, data.visitPlannedTime);
		setText(field.productName, data.productName);
		setText(field.productSize, data.productSize);
		setText(field.productColor, data.productColor);
		setText(field.onsiteContact, data.onsiteContact);
		setText(field.requestedAt, data.requestedAt);

		if (data && data.status) {
			currentTaskStatus = String(data.status);
		}

		existingResultImages = (data.resultImages || []).map(x => ({
			id: x.id,
			url: x.url,
			filename: x.filename
		}));
		requestVideos = (data.requestVideos || []).map(x => ({
			id: x.id,
			url: x.url,
			filename: x.filename,
			contentType: x.contentType
		}));

		selectedFiles = [];
		if (fileInput) {
			fileInput.value = '';
			syncFileInputFromSelectedFiles();
		}

		renderImages();
		renderRequestVideos();
		lockModalIfNotInProgress();
	}

	function openCompleteModal(taskId, statusFromRow) {
		if (!modalEl) return;

		currentTaskId = taskId;
		currentTaskStatus = statusFromRow ? String(statusFromRow) : null;

		if (currentTaskStatus !== 'IN_PROGRESS') {
			alert('진행중 건에 대해서만 가능합니다.');
			return;
		}

		if (formEl) formEl.action = `/team/asUpdate/${taskId}`;

		if (!bsModal && window.bootstrap && bootstrap.Modal) {
			bsModal = new bootstrap.Modal(modalEl);
		}

		setAlert('info', '불러오는 중입니다...');

		loadTaskForModal(taskId)
			.then(() => {
				if (currentTaskStatus !== 'IN_PROGRESS') {
					setAlert('danger', '진행중 건에 대해서만 가능합니다.');
				} else {
					setAlert(null, null);
				}
			})
			.catch(err => {
				console.error(err);
				setAlert('danger', '상세 정보를 불러오지 못했습니다.');
			})
			.finally(() => {
				applyMobileButtonsVisibility();
				if (bsModal) bsModal.show();
			});
	}

	function bindCompleteButtons() {
		document.addEventListener('click', (e) => {
			const btn = e.target.closest('.asList-second-btn-open-complete');
			if (!btn) return;

			e.preventDefault();
			e.stopPropagation();

			const taskId = btn.getAttribute('data-task-id');
			const status = btn.getAttribute('data-status');
			if (!taskId) return;

			if (String(status) !== 'IN_PROGRESS') {
				alert('진행중 건에 대해서만 가능합니다.');
				return;
			}

			openCompleteModal(taskId, status);
		});
	}

	function bindRowClickToDetail() {
		document.addEventListener('click', (e) => {
			const stop = e.target.closest('[data-stop-row="1"], button, a, input, select, textarea, label');
			if (stop && stop.closest('.asList-second-row-click')) {
				if (!stop.classList.contains('asList-second-row-click')) {
					return;
				}
			}

			const row = e.target.closest('.asList-second-row-click');
			if (!row) return;

			const href = row.getAttribute('data-href');
			if (href) window.location.href = href;
		});
	}

	function bindFormSubmitGuard() {
		if (!formEl) return;
		formEl.addEventListener('submit', (e) => {
			if (imageProcessing) {
				e.preventDefault();
				alert('이미지를 JPEG로 변환하고 있습니다. 변환이 끝난 뒤 완료처리해 주세요.');
				return;
			}

			if (currentTaskStatus !== 'IN_PROGRESS') {
				e.preventDefault();
				alert('진행중 건에 대해서만 가능합니다.');
				return;
			}

			const total = (existingResultImages?.length || 0) + (selectedFiles?.length || 0);
			if (total <= 0) {
				e.preventDefault();
				alert('이미지를 1개 이상 등록해 주세요.');
				return;
			}
		});
	}

	document.addEventListener('DOMContentLoaded', () => {
		Promise.allSettled([
			topRegionController.init(),
			modalRegionController.init()
		]).then((results) => {
			results.forEach(result => {
				if (result.status === 'rejected') console.error(result.reason);
			});
			renderCurrentFilterSummary();
			requestFloatingFilterVisibilityUpdate();
		});

		bindFilterUx();
		bindRowClickToDetail();
		bindCompleteButtons();
		bindUploadButtons();
		bindFileInput();
		bindImageListEvents();
		bindFormSubmitGuard();
		applyMobileButtonsVisibility();
	});

})();
