/* taskList.js */
document.addEventListener("DOMContentLoaded", function() {
	"use strict";

	const filterForm = document.getElementById("task-list-filter-form");
	const orderIdFromInput = document.getElementById("task-list-order-id-from-search");
	const orderIdToInput = document.getElementById("task-list-order-id-to-search");
	const dateCriteriaSelect = document.getElementById("dateCriteria");
	const startDateInput = document.getElementById("startDate");
	const endDateInput = document.getElementById("endDate");
	const singleDateInput = document.getElementById("task-list-single-date");
	const dateStepButtons = Array.from(document.querySelectorAll(".task-list-date-step"));
	const rangeToggleBtn = document.getElementById("task-list-range-toggle");
	const rangeFields = document.getElementById("task-list-range-fields");
	const pageSizeSelect = document.getElementById("task-list-added-pageSize");
	const sortStateInput = document.querySelector('input[name="sortState"]');
	const sortResetBtn = document.getElementById("task-list-sort-reset-btn");
	const searchResetBtn = document.getElementById("task-list-search-reset-btn");
	const productNameHighlightKeyword = String(
		document.querySelector(".admin-task-list-second-page")?.dataset.productNameKeyword || ""
	).trim();

	const NON_STANDARD_TASK_LIST_SORT_FIELDS = new Set([
		"orderId",
		"agencyName",
		"productCategoryName",
		"standard",
		"orderDate",
		"preferredDeliveryDate",
		"status"
	]);

	const checkAllBox = document.getElementById("task-list-check-all");
	const deleteTasksBtn = document.getElementById("task-list-delete-tasks-btn");
	const deleteOrdersBtn = document.getElementById("task-list-delete-orders-btn");
	const bulkConfirmBtn = document.getElementById("task-list-bulk-confirm-btn");
	const siteStatementBtn = document.getElementById("task-list-site-statement-btn");
	const parcelStatementBtn = document.getElementById("task-list-parcel-statement-btn");

	const csrfToken = document.getElementById("admin-task-list-second-csrf-token")?.value
		|| document.querySelector('meta[name="_csrf"]')?.getAttribute("content");
	const csrfHeader = document.getElementById("admin-task-list-second-csrf-header")?.value
		|| document.querySelector('meta[name="_csrf_header"]')?.getAttribute("content");

	const bulkOpenBtn = document.getElementById("admin-task-list-second-bulk-open-btn");
	const bulkModal = document.getElementById("admin-task-list-second-bulk-modal");
	const bulkOverlay = document.getElementById("admin-task-list-second-bulk-overlay");
	const bulkCloseBtn = document.getElementById("admin-task-list-second-bulk-close-btn");
	const bulkCheckAllBtn = document.getElementById("admin-task-list-second-bulk-check-all-btn");
	const bulkCompleteBtn = document.getElementById("admin-task-list-second-bulk-complete-btn");
	const readonlyListOpenBtn = document.getElementById("admin-task-readonly-list-open-btn");
	const readonlyListModal = document.getElementById("admin-task-readonly-list-modal");
	const readonlyListScroll = document.getElementById("admin-task-readonly-list-scroll");
	const readonlyListHost = document.getElementById("admin-task-readonly-list-host");
	const readonlyListLoading = document.getElementById("admin-task-readonly-list-loading");
	const readonlyListEnd = document.getElementById("admin-task-readonly-list-end");

	const bulkConfirmModal = document.getElementById("task-list-bulk-confirm-modal");
	const bulkConfirmModalOverlay = document.getElementById("task-list-bulk-confirm-modal-overlay");
	const bulkConfirmModalCloseBtn = document.getElementById("task-list-bulk-confirm-modal-close-btn");
	const bulkConfirmModalCancelBtn = document.getElementById("task-list-bulk-confirm-modal-cancel-btn");
	const bulkConfirmModalSubmitBtn = document.getElementById("task-list-bulk-confirm-modal-submit-btn");
	const bulkConfirmHandlerList = document.getElementById("task-list-bulk-confirm-handler-list");
	const bulkConfirmHandlerOptionSource = document.getElementById("task-list-bulk-confirm-handler-option-source");

	const REQUIRED_BULK_CONFIRM_HANDLER_METHOD_KEYWORDS = ["직배송", "현장배송"];

	const pageLoadingOverlay = document.getElementById("admin-task-list-second-loading-overlay");
	const pageLoadingMessage = document.getElementById("admin-task-list-second-loading-message");

	let bulkRowsLoaded = false;
	let pendingBulkConfirmItems = [];
	let bodyOverflowBeforeBulkConfirmModal = "";
	const detailLoadingOrderIds = new Set();
	let readonlyListPage = -1;
	let readonlyListHasNext = true;
	let readonlyListLoadingNow = false;
	let readonlyListModalInstance = null;

	function showPageLoading(message) {
		if (!pageLoadingOverlay) {
			return;
		}

		if (pageLoadingMessage && message) {
			pageLoadingMessage.textContent = message;
		}

		pageLoadingOverlay.classList.add("is-active");
		pageLoadingOverlay.setAttribute("aria-hidden", "false");
	}

	function hidePageLoading() {
		if (!pageLoadingOverlay) {
			return;
		}

		pageLoadingOverlay.classList.remove("is-active");
		pageLoadingOverlay.setAttribute("aria-hidden", "true");
	}

	window.addEventListener("load", hidePageLoading);


	function parseSortState(rawSortState) {
		const criteria = [];
		const seenFields = new Set();

		String(rawSortState || "")
			.split("|")
			.forEach(token => {
				const normalizedToken = token.trim();
				if (!normalizedToken) {
					return;
				}

				const separatorIndex = normalizedToken.indexOf(":");
				if (separatorIndex <= 0) {
					return;
				}

				const field = normalizedToken.substring(0, separatorIndex).trim();
				const direction = normalizedToken.substring(separatorIndex + 1).trim().toLowerCase();

				if (!NON_STANDARD_TASK_LIST_SORT_FIELDS.has(field)) {
					return;
				}

				if (direction !== "asc" && direction !== "desc") {
					return;
				}

				if (seenFields.has(field)) {
					const existing = criteria.find(item => item.field === field);
					if (existing) {
						existing.direction = direction;
					}
					return;
				}

				seenFields.add(field);
				criteria.push({ field, direction });
			});

		return criteria;
	}

	function serializeSortState(criteria) {
		return (criteria || [])
			.filter(item => NON_STANDARD_TASK_LIST_SORT_FIELDS.has(item.field))
			.filter(item => item.direction === "asc" || item.direction === "desc")
			.map(item => item.field + ":" + item.direction)
			.join("|");
	}

	function getNormalizedSortState() {
		const hiddenValue = sortStateInput?.value || "";
		if (hiddenValue) {
			return serializeSortState(parseSortState(hiddenValue));
		}

		const params = new URLSearchParams(window.location.search);
		return serializeSortState(parseSortState(params.get("sortState") || ""));
	}

	function navigateTaskList(url, loadingMessage) {
		showPageLoading(loadingMessage || "목록을 불러오는 중입니다.");
		window.location.assign(url.pathname + url.search);
	}

	function applySortLink(link) {
		if (!link) {
			return;
		}

		const field = link.dataset.sortField || "";
		const direction = (link.dataset.sortDir || "").toLowerCase();

		if (!NON_STANDARD_TASK_LIST_SORT_FIELDS.has(field)) {
			return;
		}

		if (direction !== "asc" && direction !== "desc") {
			return;
		}

		const criteria = parseSortState(getNormalizedSortState());
		const existingIndex = criteria.findIndex(item => item.field === field);

		if (existingIndex >= 0 && criteria[existingIndex].direction === direction) {
			criteria.splice(existingIndex, 1);
		} else if (existingIndex >= 0) {
			criteria[existingIndex].direction = direction;
		} else {
			criteria.push({ field, direction });
		}

		const url = new URL(window.location.href);
		const nextSortState = serializeSortState(criteria);

		url.searchParams.delete("page");
		url.searchParams.delete("sortField");
		url.searchParams.delete("sortDir");

		if (nextSortState) {
			url.searchParams.set("sortState", nextSortState);
		} else {
			url.searchParams.delete("sortState");
		}

		navigateTaskList(url, "정렬을 적용하는 중입니다.");
	}

	function resetSortOnly() {
		const url = new URL(window.location.href);

		url.searchParams.delete("page");
		url.searchParams.delete("sortState");
		url.searchParams.delete("sortField");
		url.searchParams.delete("sortDir");

		navigateTaskList(url, "정렬을 초기화하는 중입니다.");
	}

	function parsePositiveIntegerInput(input) {
		if (!input) {
			return null;
		}

		const raw = String(input.value || "").trim();
		if (!raw) {
			return null;
		}

		const value = Number(raw);
		return Number.isInteger(value) && value > 0 ? value : null;
	}

	function validateOrderIdRange() {
		const fromRaw = String(orderIdFromInput?.value || "").trim();
		const toRaw = String(orderIdToInput?.value || "").trim();
		const from = parsePositiveIntegerInput(orderIdFromInput);
		const to = parsePositiveIntegerInput(orderIdToInput);

		if (fromRaw && from == null) {
			alert("오더 ID FROM은 1 이상의 정수로 입력해 주세요.");
			orderIdFromInput?.focus();
			return false;
		}

		if (toRaw && to == null) {
			alert("오더 ID TO는 1 이상의 정수로 입력해 주세요.");
			orderIdToInput?.focus();
			return false;
		}

		if (from != null && to != null && from > to) {
			alert("오더 ID TO는 FROM보다 크거나 같아야 합니다.\n단건 조회는 FROM과 TO에 같은 값을 입력해 주세요.");
			orderIdToInput?.focus();
			return false;
		}

		return true;
	}

	function resetSearchOnly() {
		const url = new URL(window.location.href);
		const currentSortState = getNormalizedSortState();

		[
			"page",
			"keyword",
			"orderIdFrom",
			"orderIdTo",
			"orderId",
			"productName",
			"dateCriteria",
			"startDate",
			"endDate",
			"productCategoryId",
			"orderStatus",
			"standard",
			"sortState",
			"sortField",
			"sortDir"
		].forEach(parameterName => url.searchParams.delete(parameterName));

		if (currentSortState) {
			url.searchParams.set("sortState", currentSortState);
		}

		navigateTaskList(url, "검색 조건을 초기화하는 중입니다.");
	}

	function highlightProductNameMatches(root) {
		const keyword = productNameHighlightKeyword;
		if (!keyword) {
			return;
		}

		const base = root || document;
		const normalizedKeyword = keyword.toLocaleLowerCase();

		base.querySelectorAll(".admin-task-list-second-product-highlight-target").forEach(target => {
			if (!target || target.dataset.productHighlightApplied === "true") {
				return;
			}

			const originalText = String(target.textContent || "");
			const normalizedText = originalText.toLocaleLowerCase();
			let searchIndex = 0;
			let matchIndex = normalizedText.indexOf(normalizedKeyword, searchIndex);

			if (matchIndex < 0) {
				target.dataset.productHighlightApplied = "true";
				return;
			}

			const fragment = document.createDocumentFragment();

			while (matchIndex >= 0) {
				if (matchIndex > searchIndex) {
					fragment.appendChild(document.createTextNode(originalText.slice(searchIndex, matchIndex)));
				}

				const highlighted = document.createElement("span");
				highlighted.className = "admin-task-list-second-product-highlight";
				highlighted.textContent = originalText.slice(matchIndex, matchIndex + keyword.length);
				fragment.appendChild(highlighted);

				searchIndex = matchIndex + keyword.length;
				matchIndex = normalizedText.indexOf(normalizedKeyword, searchIndex);
			}

			if (searchIndex < originalText.length) {
				fragment.appendChild(document.createTextNode(originalText.slice(searchIndex)));
			}

			target.replaceChildren(fragment);
			target.dataset.productHighlightApplied = "true";
		});
	}

	function buildJsonHeaders() {
		const headers = {
			"Content-Type": "application/json"
		};

		if (csrfHeader && csrfToken) {
			headers[csrfHeader] = csrfToken;
		}

		return headers;
	}

	function getOrderCheckboxes() {
		return Array.from(document.querySelectorAll(".task-list-order-checkbox"));
	}

	function getSelectedOrderItems() {
		return getOrderCheckboxes()
			.filter(checkbox => checkbox.checked)
			.map(checkbox => {
				const row = checkbox.closest(".admin-task-list-second-main-row");
				const orderId = Number(checkbox.value);

				const rawHandlerId = checkbox.dataset.assignedDeliveryHandlerId
					|| row?.dataset.assignedDeliveryHandlerId
					|| "";
				const parsedHandlerId = Number(rawHandlerId);

				return {
					orderId,
					statusName: checkbox.dataset.orderStatus || row?.dataset.orderStatus || "",
					statusLabel: checkbox.dataset.orderStatusLabel || row?.dataset.orderStatusLabel || "",
					deliveryMethodName: checkbox.dataset.deliveryMethodName || row?.dataset.deliveryMethodName || "",
					assignedDeliveryHandlerId: Number.isFinite(parsedHandlerId) && parsedHandlerId > 0
						? parsedHandlerId
						: null,
					assignedDeliveryHandlerName: checkbox.dataset.assignedDeliveryHandlerName
						|| row?.dataset.assignedDeliveryHandlerName
						|| "",
					preferredDeliveryDate: checkbox.dataset.preferredDeliveryDate
						|| row?.dataset.preferredDeliveryDate
						|| ""
				};
			})
			.filter(item => !Number.isNaN(item.orderId));
	}

	function getSelectedOrderIds() {
		return getSelectedOrderItems().map(item => item.orderId);
	}

	function updateDateInputs() {
		if (!dateCriteriaSelect || !startDateInput || !endDateInput) {
			return;
		}

		const selectedValue = dateCriteriaSelect.value;
		const shouldEnable = selectedValue === "order" || selectedValue === "delivery";

		startDateInput.disabled = !shouldEnable;
		endDateInput.disabled = !shouldEnable;
		if (singleDateInput) singleDateInput.disabled = !shouldEnable;
		dateStepButtons.forEach(button => { button.disabled = !shouldEnable; });
		if (rangeToggleBtn) rangeToggleBtn.disabled = !shouldEnable;

		if (!shouldEnable) {
			rangeFields?.classList.add("d-none");
			rangeToggleBtn?.setAttribute("aria-expanded", "false");
			rangeToggleBtn?.classList.remove("is-active");
		}
	}

	function formatLocalDate(date) {
		const year = date.getFullYear();
		const month = String(date.getMonth() + 1).padStart(2, "0");
		const day = String(date.getDate()).padStart(2, "0");
		return `${year}-${month}-${day}`;
	}

	function canUseSelectedDateCriteria() {
		if (dateCriteriaSelect && dateCriteriaSelect.value === "all") {
			alert("날짜를 조회하려면 기준일을 발주일 또는 출고일로 선택해 주세요.");
			dateCriteriaSelect.focus();
			return false;
		}
		return true;
	}

	function parseLocalDate(value) {
		const matched = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
		if (!matched) return null;
		const parsed = new Date(Number(matched[1]), Number(matched[2]) - 1, Number(matched[3]), 12, 0, 0, 0);
		return Number.isNaN(parsed.getTime()) ? null : parsed;
	}

	function applySingleDate(dateValue) {
		if (!filterForm || !startDateInput || !endDateInput || !dateValue) {
			return;
		}
		if (!canUseSelectedDateCriteria()) return;
		if (singleDateInput) singleDateInput.value = dateValue;
		startDateInput.value = dateValue;
		endDateInput.value = dateValue;
		rangeFields?.classList.add("d-none");
		rangeToggleBtn?.setAttribute("aria-expanded", "false");
		rangeToggleBtn?.classList.remove("is-active");
		filterForm.requestSubmit();
	}

	function submitDateStep(rawStep) {
		if (!canUseSelectedDateCriteria()) return;
		const step = Number(rawStep);
		const base = parseLocalDate(singleDateInput?.value)
			|| parseLocalDate(startDateInput?.value)
			|| new Date();
		base.setHours(12, 0, 0, 0);
		base.setDate(base.getDate() + (Number.isFinite(step) ? step : 0));
		applySingleDate(formatLocalDate(base));
	}

	function toggleRangeSearch() {
		if (!rangeFields || !rangeToggleBtn) {
			return;
		}

		if (!canUseSelectedDateCriteria()) return;
		const willOpen = rangeFields.classList.contains("d-none");
		rangeFields.classList.toggle("d-none", !willOpen);
		rangeToggleBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
		rangeToggleBtn.classList.toggle("is-active", willOpen);
		if (willOpen) {
			const fallbackDate = singleDateInput?.value || formatLocalDate(new Date());
			if (!startDateInput.value) startDateInput.value = fallbackDate;
			if (!endDateInput.value) endDateInput.value = fallbackDate;
			window.requestAnimationFrame(function() {
				startDateInput?.focus({ preventScroll: true });
			});
		}
	}

	function updateReadonlyGallery(gallery, requestedIndex) {
		if (!gallery) return;
		const track = gallery.querySelector("[data-readonly-gallery-track]");
		const slides = Array.from(gallery.querySelectorAll(".admin-task-readonly-gallery-slide"));
		if (!track || !slides.length) return;

		const rawIndex = Number(requestedIndex);
		const safeIndex = Number.isFinite(rawIndex)
			? ((Math.trunc(rawIndex) % slides.length) + slides.length) % slides.length
			: 0;

		gallery.dataset.currentIndex = String(safeIndex);
		track.style.transform = `translate3d(-${safeIndex * 100}%, 0, 0)`;
		gallery.querySelectorAll("[data-readonly-gallery-current]").forEach(node => {
			node.textContent = String(safeIndex + 1);
		});
		slides.forEach((slide, index) => {
			slide.tabIndex = index === safeIndex ? 0 : -1;
			slide.setAttribute("aria-hidden", index === safeIndex ? "false" : "true");
		});
		gallery.querySelectorAll("[data-readonly-gallery-go]").forEach(dot => {
			const active = Number(dot.dataset.readonlyGalleryGo) === safeIndex;
			dot.classList.toggle("is-active", active);
			dot.setAttribute("aria-current", active ? "true" : "false");
		});
	}

	function moveReadonlyGallery(gallery, step) {
		const currentIndex = Number(gallery?.dataset.currentIndex || 0);
		updateReadonlyGallery(gallery, currentIndex + Number(step || 0));
	}

	function initializeReadonlyGalleries(root) {
		(root || document).querySelectorAll("[data-readonly-gallery]").forEach(gallery => {
			updateReadonlyGallery(gallery, Number(gallery.dataset.currentIndex || 0));
			if (gallery.dataset.touchReady === "true") return;

			gallery.dataset.touchReady = "true";
			const viewport = gallery.querySelector(".admin-task-readonly-gallery-viewport");
			if (!viewport) return;
			let touchStartX = null;
			viewport.addEventListener("touchstart", event => {
				touchStartX = event.touches?.[0]?.clientX ?? null;
			}, { passive: true });
			viewport.addEventListener("touchend", event => {
				if (touchStartX == null) return;
				const touchEndX = event.changedTouches?.[0]?.clientX;
				if (typeof touchEndX === "number" && Math.abs(touchEndX - touchStartX) >= 42) {
					gallery.dataset.lastSwipeAt = String(Date.now());
					moveReadonlyGallery(gallery, touchEndX < touchStartX ? 1 : -1);
				}
				touchStartX = null;
			}, { passive: true });
		});
	}

	async function loadReadonlyListBatch(reset) {
		if (!readonlyListHost || readonlyListLoadingNow || (!reset && !readonlyListHasNext)) {
			return;
		}

		readonlyListLoadingNow = true;
		readonlyListLoading?.classList.remove("d-none");
		readonlyListEnd?.classList.add("d-none");

		const nextPage = reset ? 0 : readonlyListPage + 1;
		const url = new URL("/management/nonStandardTaskList/readonly-list-fragment", window.location.origin);
		const params = new URLSearchParams(window.location.search);
		params.delete("page");
		params.delete("size");
		params.set("modalPage", String(nextPage));
		url.search = params.toString();

		try {
			const response = await fetch(url.toString(), {
				headers: { "X-Requested-With": "XMLHttpRequest" }
			});
			if (!response.ok) {
				throw new Error("읽기 전용 목록을 불러오지 못했습니다.");
			}

			const template = document.createElement("template");
			template.innerHTML = (await response.text()).trim();
			const meta = template.content.querySelector(".admin-task-readonly-list-batch-meta");
			if (!meta) {
				throw new Error("목록 응답 형식이 올바르지 않습니다.");
			}

			readonlyListPage = Number(meta.dataset.page || nextPage);
			readonlyListHasNext = meta.dataset.hasNext === "true";
			meta.remove();

			if (reset) {
				readonlyListHost.replaceChildren();
			}
			readonlyListHost.appendChild(template.content);
			initializeReadonlyGalleries(readonlyListHost);
			readonlyListEnd?.classList.toggle("d-none", readonlyListHasNext || readonlyListPage < 0);
		} catch (error) {
			alert(error.message || "읽기 전용 목록 조회 중 오류가 발생했습니다.");
		} finally {
			readonlyListLoadingNow = false;
			readonlyListLoading?.classList.add("d-none");
		}
	}

	function openReadonlyListModal() {
		if (!readonlyListModal || !window.bootstrap?.Modal) {
			alert("목록 모달을 열 수 없습니다. 페이지를 새로고침해 주세요.");
			return;
		}

		readonlyListModalInstance = window.bootstrap.Modal.getOrCreateInstance(readonlyListModal);
		readonlyListModalInstance.show();
		if (readonlyListPage < 0) {
			loadReadonlyListBatch(true);
		}
	}

	function updateBulkButtons() {
		const checkboxes = getOrderCheckboxes();
		const checkedCount = checkboxes.filter(cb => cb.checked).length;
		const totalCount = checkboxes.length;

		if (deleteTasksBtn) {
			deleteTasksBtn.disabled = checkedCount === 0;
		}

		if (deleteOrdersBtn) {
			deleteOrdersBtn.disabled = checkedCount === 0;
		}

		if (bulkConfirmBtn) {
			bulkConfirmBtn.disabled = checkedCount === 0;
		}

		if (siteStatementBtn) {
			siteStatementBtn.disabled = checkedCount === 0;
		}

		if (parcelStatementBtn) {
			parcelStatementBtn.disabled = checkedCount === 0;
		}

		if (checkAllBox) {
			checkAllBox.checked = totalCount > 0 && checkedCount === totalCount;
			checkAllBox.indeterminate = checkedCount > 0 && checkedCount < totalCount;
		}
	}


	async function downloadDeliveryStatement(statementType, button) {
		const selectedOrderIds = getSelectedOrderIds();

		if (selectedOrderIds.length === 0) {
			alert("명세서로 출력할 주문을 하나 이상 선택해 주세요.");
			return;
		}

		const originalText = button ? button.innerHTML : "";

		try {
			setStatementButtonsBusy(true, button);

			const response = await fetch("/api/internal/delivery-statement/excel", {
				method: "POST",
				headers: buildJsonHeaders(),
				body: JSON.stringify({
					statementType: statementType,
					orderIds: selectedOrderIds
				})
			});

			if (!response.ok) {
				const errorText = await response.text();
				throw new Error(errorText || "명세서 출력 중 오류가 발생했습니다.");
			}

			const blob = await response.blob();
			const contentDisposition = response.headers.get("Content-Disposition");
			const filename = resolveDeliveryStatementFilename(
				contentDisposition,
				(statementType === "SITE" ? "현장명세서" : "택배명세서") + "_" + new Date().toISOString().slice(0, 10) + ".xlsx"
			);

			downloadBlob(blob, filename);
		} catch (error) {
			alert(error.message || "명세서 출력 중 오류가 발생했습니다.");
		} finally {
			setStatementButtonsBusy(false, button, originalText);
		}
	}

	function setStatementButtonsBusy(isBusy, activeButton, originalText) {
		[siteStatementBtn, parcelStatementBtn].forEach(btn => {
			if (!btn) {
				return;
			}

			if (isBusy) {
				btn.disabled = true;
				if (btn === activeButton) {
					btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 명세서 생성중';
				}
				return;
			}

			if (btn === activeButton && originalText) {
				btn.innerHTML = originalText;
			}
		});

		if (!isBusy) {
			updateBulkButtons();
		}
	}

	function downloadBlob(blob, filename) {
		const url = window.URL.createObjectURL(blob);
		const link = document.createElement("a");

		link.href = url;
		link.download = filename;
		document.body.appendChild(link);
		link.click();
		link.remove();

		window.URL.revokeObjectURL(url);
	}

	function resolveDeliveryStatementFilename(contentDisposition, fallbackFilename) {
		if (contentDisposition) {
			const utf8Match = contentDisposition.match(/filename\*=UTF-8''([^;]+)/i);
			if (utf8Match && utf8Match[1]) {
				return decodeURIComponent(utf8Match[1].replace(/"/g, ""));
			}

			const asciiMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
			if (asciiMatch && asciiMatch[1]) {
				return asciiMatch[1];
			}
		}

		return fallbackFilename;
	}

	function setDeleteButtonsBusy(isBusy) {
		const selectedCount = getSelectedOrderIds().length;

		[deleteTasksBtn, deleteOrdersBtn].forEach(btn => {
			if (!btn) {
				return;
			}

			btn.disabled = isBusy || selectedCount === 0;

			if (isBusy) {
				if (!btn.dataset.originalText) {
					btn.dataset.originalText = btn.innerHTML;
				}
				btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 삭제중';
				return;
			}

			if (btn.dataset.originalText) {
				btn.innerHTML = btn.dataset.originalText;
				btn.dataset.originalText = "";
			}
		});
	}

	async function callDeleteApi(url, confirmMessage) {
		const selectedOrderIds = getSelectedOrderIds();

		if (selectedOrderIds.length === 0) {
			alert("삭제할 주문을 하나 이상 선택해 주세요.");
			return;
		}

		if (!confirm(confirmMessage)) {
			return;
		}

		try {
			setDeleteButtonsBusy(true);

			const response = await fetch(url, {
				method: "POST",
				headers: buildJsonHeaders(),
				body: JSON.stringify({ orderIds: selectedOrderIds })
			});

			let data = null;
			try {
				data = await response.json();
			} catch (e) {
				data = null;
			}

			if (!response.ok || !data || data.success !== true) {
				throw new Error(data?.message || "삭제 처리 중 오류가 발생했습니다.");
			}

			alert(data.message || "삭제가 완료되었습니다.");
			showPageLoading("목록을 다시 불러오는 중입니다.");
			window.location.reload();
		} catch (error) {
			alert(error.message || "삭제 처리 중 오류가 발생했습니다.");
		} finally {
			setDeleteButtonsBusy(false);
			updateBulkButtons();
		}
	}

	function findFirstNotRequestedSelectedOrder() {
		return getSelectedOrderItems().find(item => {
			if (!item.statusName) {
				return false;
			}

			return item.statusName !== "REQUESTED";
		});
	}

	function normalizeBulkConfirmMethodName(value) {
		return String(value || "").trim().replace(/\s+/g, "");
	}

	function bulkConfirmMethodRequiresHandler(methodName) {
		const normalized = normalizeBulkConfirmMethodName(methodName);
		return REQUIRED_BULK_CONFIRM_HANDLER_METHOD_KEYWORDS.some(keyword => normalized.includes(keyword));
	}

	function setBulkConfirmBusy(isBusy) {
		if (bulkConfirmBtn) {
			const selectedCount = getSelectedOrderIds().length;
			bulkConfirmBtn.disabled = isBusy || selectedCount === 0;

			if (isBusy) {
				if (!bulkConfirmBtn.dataset.originalText) {
					bulkConfirmBtn.dataset.originalText = bulkConfirmBtn.innerHTML;
				}
				bulkConfirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 컨펌중';
			} else if (bulkConfirmBtn.dataset.originalText) {
				bulkConfirmBtn.innerHTML = bulkConfirmBtn.dataset.originalText;
				bulkConfirmBtn.dataset.originalText = "";
			}
		}

		if (bulkConfirmModalSubmitBtn) {
			bulkConfirmModalSubmitBtn.disabled = isBusy;
			bulkConfirmModalSubmitBtn.textContent = isBusy ? "저장 중..." : "승인 완료 저장";
		}

		[
			bulkConfirmModalCloseBtn,
			bulkConfirmModalCancelBtn
		].forEach(button => {
			if (button) {
				button.disabled = isBusy;
			}
		});
	}

	function buildBulkConfirmHandlerSelect(orderItem) {
		const select = document.createElement("select");
		select.className = "form-select task-list-bulk-confirm-handler-select";
		select.dataset.orderId = String(orderItem.orderId);

		if (bulkConfirmHandlerOptionSource) {
			select.innerHTML = bulkConfirmHandlerOptionSource.innerHTML;
		} else {
			const emptyOption = document.createElement("option");
			emptyOption.value = "";
			emptyOption.textContent = "배송팀 담당자 선택";
			select.appendChild(emptyOption);
		}

		if (orderItem.assignedDeliveryHandlerId) {
			select.value = String(orderItem.assignedDeliveryHandlerId);
		}

		return select;
	}

	function renderBulkConfirmHandlerRows(items) {
		if (!bulkConfirmHandlerList) {
			return;
		}

		bulkConfirmHandlerList.innerHTML = "";

		items
			.filter(item => bulkConfirmMethodRequiresHandler(item.deliveryMethodName))
			.forEach(item => {
				const row = document.createElement("div");
				row.className = "border rounded p-3 mb-2";

				const header = document.createElement("div");
				header.className = "d-flex align-items-center justify-content-between gap-2 mb-2";

				const title = document.createElement("strong");
				title.textContent = "ORDER " + item.orderId;

				const badge = document.createElement("span");
				badge.className = "badge bg-warning-subtle text-warning";
				badge.textContent = item.deliveryMethodName || "담당자 필수 배송수단";

				header.appendChild(title);
				header.appendChild(badge);

				const dateText = document.createElement("div");
				dateText.className = item.preferredDeliveryDate
					? "small text-muted mb-2"
					: "small text-danger mb-2";
				dateText.textContent = item.preferredDeliveryDate
					? "배송희망일: " + item.preferredDeliveryDate
					: "배송희망일이 없습니다. 넓게보기에서 배송희망일을 먼저 지정해야 합니다.";

				const select = buildBulkConfirmHandlerSelect(item);

				row.appendChild(header);
				row.appendChild(dateText);
				row.appendChild(select);
				bulkConfirmHandlerList.appendChild(row);
			});
	}

	function openBulkConfirmModal(items) {
		if (!bulkConfirmModal) {
			alert("배송담당자 선택 화면을 찾을 수 없습니다.");
			return;
		}

		pendingBulkConfirmItems = Array.isArray(items) ? items.slice() : [];
		renderBulkConfirmHandlerRows(pendingBulkConfirmItems);

		bodyOverflowBeforeBulkConfirmModal = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		bulkConfirmModal.classList.remove("d-none");
		bulkConfirmModal.setAttribute("aria-hidden", "false");

		const firstSelect = bulkConfirmModal.querySelector(".task-list-bulk-confirm-handler-select");
		if (firstSelect) {
			setTimeout(() => firstSelect.focus(), 0);
		}
	}

	function closeBulkConfirmModal() {
		if (!bulkConfirmModal || bulkConfirmModalSubmitBtn?.disabled) {
			return;
		}

		bulkConfirmModal.classList.add("d-none");
		bulkConfirmModal.setAttribute("aria-hidden", "true");
		document.body.style.overflow = bodyOverflowBeforeBulkConfirmModal;
		pendingBulkConfirmItems = [];
		if (bulkConfirmHandlerList) {
			bulkConfirmHandlerList.innerHTML = "";
		}
	}

	function collectBulkConfirmHandlerAssignments() {
		const assignments = new Map();

		for (const item of pendingBulkConfirmItems) {
			if (!bulkConfirmMethodRequiresHandler(item.deliveryMethodName)) {
				continue;
			}

			if (!item.preferredDeliveryDate) {
				throw new Error(item.orderId + "번 오더는 배송희망일이 없습니다.\n넓게보기에서 배송희망일을 지정한 뒤 다시 시도해 주세요.");
			}

			const select = bulkConfirmHandlerList?.querySelector(
				'.task-list-bulk-confirm-handler-select[data-order-id="' + item.orderId + '"]'
			);
			const handlerId = Number(select?.value || 0);

			if (!Number.isFinite(handlerId) || handlerId <= 0) {
				throw new Error(item.orderId + "번 오더의 배송팀 담당자를 선택해 주세요.");
			}

			assignments.set(item.orderId, handlerId);
		}

		return assignments;
	}

	async function executeBulkConfirm(items, handlerAssignments) {
		if (!Array.isArray(items) || items.length === 0) {
			alert("컨펌 처리할 주문이 없습니다.");
			return;
		}

		const assignments = handlerAssignments instanceof Map
			? handlerAssignments
			: new Map();

		try {
			setBulkConfirmBusy(true);

			const response = await fetch("/management/nonStandardTaskList/bulk-confirm", {
				method: "POST",
				headers: buildJsonHeaders(),
				body: JSON.stringify({
					orders: items.map(item => ({
						orderId: item.orderId,
						deliveryHandlerId: assignments.get(item.orderId) || null
					}))
				})
			});

			let data = null;
			try {
				data = await response.json();
			} catch (e) {
				data = null;
			}

			if (!response.ok || !data || data.success !== true) {
				throw new Error(data?.message || "일괄 컨펌 처리 중 오류가 발생했습니다.");
			}

			if (bulkConfirmModal && !bulkConfirmModal.classList.contains("d-none")) {
				bulkConfirmModal.classList.add("d-none");
				bulkConfirmModal.setAttribute("aria-hidden", "true");
				document.body.style.overflow = bodyOverflowBeforeBulkConfirmModal;
			}

			alert(data.message || "일괄 컨펌이 완료되었습니다.");
			showPageLoading("목록을 다시 불러오는 중입니다.");
			window.location.reload();
		} catch (error) {
			alert(error.message || "일괄 컨펌 처리 중 오류가 발생했습니다.");
		} finally {
			setBulkConfirmBusy(false);
			updateBulkButtons();
		}
	}

	async function submitBulkConfirmModal() {
		try {
			const assignments = collectBulkConfirmHandlerAssignments();

			if (!confirm(pendingBulkConfirmItems.length + "건을 승인완료로 변경하고 배송순서를 생성하시겠습니까?")) {
				return;
			}

			await executeBulkConfirm(pendingBulkConfirmItems, assignments);
		} catch (error) {
			alert(error.message || "배송담당자 선택값을 확인해 주세요.");
		}
	}

	async function bulkConfirmSelectedOrders() {
		const selectedItems = getSelectedOrderItems();

		if (selectedItems.length === 0) {
			alert("컨펌 처리할 주문을 하나 이상 선택해 주세요.");
			return;
		}

		const blockedOrder = selectedItems.find(item => item.statusName && item.statusName !== "REQUESTED");
		if (blockedOrder) {
			const label = blockedOrder.statusLabel || blockedOrder.statusName || "고객 발주가 아닌 상태";
			alert(blockedOrder.orderId + "번 오더는 현재 '" + label + "' 상태입니다.\n고객 발주 상태만 일괄 컨펌할 수 있으니 해당 오더 체크를 해제 후 다시 시도해 주세요.");
			return;
		}

		const requiredHandlerItems = selectedItems.filter(item => {
			return bulkConfirmMethodRequiresHandler(item.deliveryMethodName);
		});

		if (requiredHandlerItems.length > 0) {
			openBulkConfirmModal(selectedItems);
			return;
		}

		if (!confirm(selectedItems.length + "건을 승인완료로 변경하시겠습니까?")) {
			return;
		}

		await executeBulkConfirm(selectedItems, new Map());
	}

	function setWideButtonState(button, isOpen, isBusy) {
		if (!button) {
			return;
		}

		if (isBusy) {
			button.disabled = true;
			button.title = "로딩중";
			button.setAttribute("aria-label", "로딩중");
			button.innerHTML = '<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i><span class="visually-hidden">로딩중</span>';
			return;
		}

		const label = isOpen ? "닫기" : "넓게보기";
		const iconClass = isOpen ? "fa-solid fa-compress" : "fa-solid fa-up-right-and-down-left-from-center";

		button.disabled = false;
		button.title = label;
		button.setAttribute("aria-label", label);
		button.innerHTML = '<i class="' + iconClass + '" aria-hidden="true"></i><span class="visually-hidden">' + label + '</span>';
		button.classList.toggle("btn-primary", isOpen);
		button.classList.toggle("btn-outline-primary", !isOpen);
	}

	function findDetailRow(orderId) {
		return document.querySelector(`.admin-task-list-second-detail-row[data-order-id="${orderId}"]`);
	}

	function toggleOrderHistory(button) {
		if (!button) {
			return;
		}

		const targetId = button.dataset.targetId;
		if (!targetId) {
			return;
		}

		const body = document.getElementById(targetId);
		if (!body) {
			return;
		}

		const willOpen = body.classList.contains("d-none");
		body.classList.toggle("d-none", !willOpen);
		button.setAttribute("aria-expanded", String(willOpen));

		const icon = button.querySelector("i");
		if (icon) {
			icon.classList.toggle("fa-chevron-down", !willOpen);
			icon.classList.toggle("fa-chevron-up", willOpen);
		}

		const label = button.querySelector(".admin-task-list-second-history-toggle-label");
		if (label) {
			label.textContent = willOpen ? "닫기" : "펼치기";
		}
	}

	function openExistingDetailRow(orderId, forceOpen) {
		const row = findDetailRow(orderId);
		const button = document.querySelector(`.admin-task-list-second-wide-toggle-btn[data-order-id="${orderId}"]`);

		if (!row) {
			return false;
		}

		const isOpen = !row.classList.contains("d-none");
		const nextOpen = typeof forceOpen === "boolean" ? forceOpen : !isOpen;

		row.classList.toggle("d-none", !nextOpen);
		setWideButtonState(button, nextOpen, false);
		return true;
	}

	function getCurrentReturnUrl() {
		return window.location.pathname + window.location.search;
	}

	async function loadDetailRow(orderId) {
		const mainRow = document.querySelector(`.admin-task-list-second-main-row[data-order-id="${orderId}"]`);
		const button = document.querySelector(`.admin-task-list-second-wide-toggle-btn[data-order-id="${orderId}"]`);

		if (!mainRow || !orderId) {
			return;
		}

		if (detailLoadingOrderIds.has(String(orderId))) {
			return;
		}

		detailLoadingOrderIds.add(String(orderId));
		setWideButtonState(button, false, true);
		showPageLoading("주문 상세 정보를 불러오는 중입니다.");

		try {
			const url = new URL(`/management/nonStandardTaskList/order-detail-fragment/${orderId}`, window.location.origin);
			url.searchParams.set("returnUrl", getCurrentReturnUrl());

			const response = await fetch(url.toString(), {
				method: "GET",
				headers: {
					"X-Requested-With": "XMLHttpRequest"
				}
			});

			if (!response.ok) {
				throw new Error("주문 상세 정보를 불러오지 못했습니다.");
			}

			const html = await response.text();
			const template = document.createElement("template");
			template.innerHTML = html.trim();

			const detailRow = template.content.querySelector(".admin-task-list-second-detail-row");

			if (!detailRow) {
				throw new Error("주문 상세 화면 응답 형식이 올바르지 않습니다.");
			}

			mainRow.insertAdjacentElement("afterend", detailRow);

			initializeImageSection(detailRow);

			if (window.AdminTaskListSecondOrderEditExtension?.initForm) {
				const form = detailRow.querySelector(".admin-task-list-second-update-form");
				window.AdminTaskListSecondOrderEditExtension.initForm(form);
			}

			setWideButtonState(button, true, false);
		} catch (error) {
			alert(error.message || "주문 상세 정보를 불러오는 중 오류가 발생했습니다.");
			setWideButtonState(button, false, false);
		} finally {
			detailLoadingOrderIds.delete(String(orderId));
			hidePageLoading();
		}
	}

	async function toggleDetailRow(orderId, forceOpen) {
		if (!orderId) {
			return;
		}

		const existingRow = findDetailRow(orderId);

		if (existingRow) {
			openExistingDetailRow(orderId, forceOpen);
			return;
		}

		if (forceOpen === false) {
			return;
		}

		await loadDetailRow(orderId);
	}

	async function loadBulkRowsIfNeeded() {
		if (bulkRowsLoaded) {
			return;
		}

		const bulkList = document.getElementById("admin-task-list-second-bulk-list");

		if (!bulkList) {
			return;
		}

		const url = new URL("/management/nonStandardTaskList/bulk-fragment", window.location.origin);
		// 현재 목록의 page/size/검색/정렬 조건을 그대로 전달하여 현재 페이지 주문만 조회합니다.
		const params = new URLSearchParams(window.location.search);
		url.search = params.toString();

		try {
			showPageLoading("일괄보기 데이터를 불러오는 중입니다.");

			const response = await fetch(url.toString(), {
				method: "GET",
				headers: {
					"X-Requested-With": "XMLHttpRequest"
				}
			});

			if (!response.ok) {
				throw new Error("일괄보기 데이터를 불러오지 못했습니다.");
			}

			bulkList.innerHTML = await response.text();
			highlightProductNameMatches(bulkList);
			bulkRowsLoaded = true;
			updateBulkModalButtons();
		} catch (error) {
			alert(error.message || "일괄보기 데이터를 불러오는 중 오류가 발생했습니다.");
		} finally {
			hidePageLoading();
		}
	}

	async function openBulkModal() {
		if (!bulkModal) {
			return;
		}

		bulkModal.classList.add("is-open");
		bulkModal.setAttribute("aria-hidden", "false");
		document.body.classList.add("admin-task-list-second-modal-open");

		await loadBulkRowsIfNeeded();
		updateBulkModalButtons();
	}

	function closeBulkModal() {
		if (!bulkModal) {
			return;
		}

		bulkModal.classList.remove("is-open");
		bulkModal.setAttribute("aria-hidden", "true");
		document.body.classList.remove("admin-task-list-second-modal-open");
	}

	function getBulkPendingCheckboxes() {
		return Array.from(document.querySelectorAll(".admin-task-list-second-bulk-checkbox"))
			.filter(checkbox => !checkbox.disabled);
	}

	function getSelectedBulkOrderIds() {
		return getBulkPendingCheckboxes()
			.filter(checkbox => checkbox.checked)
			.map(checkbox => Number(checkbox.value))
			.filter(id => !Number.isNaN(id));
	}

	function updateBulkModalButtons() {
		const pendingCheckboxes = getBulkPendingCheckboxes();
		const checkedCount = pendingCheckboxes.filter(checkbox => checkbox.checked).length;
		const totalCount = pendingCheckboxes.length;

		if (bulkCompleteBtn) {
			bulkCompleteBtn.disabled = checkedCount === 0;
		}

		if (bulkCheckAllBtn) {
			const allChecked = totalCount > 0 && checkedCount === totalCount;
			bulkCheckAllBtn.textContent = allChecked ? "체크해제" : "일괄체크";
			bulkCheckAllBtn.dataset.allChecked = allChecked ? "true" : "false";
			bulkCheckAllBtn.disabled = totalCount === 0;
		}
	}

	function toggleBulkAllCheck() {
		const pendingCheckboxes = getBulkPendingCheckboxes();

		if (pendingCheckboxes.length === 0) {
			updateBulkModalButtons();
			return;
		}

		const allChecked = pendingCheckboxes.every(checkbox => checkbox.checked);
		const nextChecked = !allChecked;

		pendingCheckboxes.forEach(checkbox => {
			checkbox.checked = nextChecked;
		});

		updateBulkModalButtons();
	}

	function setBulkCompleteBusy(isBusy) {
		if (!bulkCompleteBtn) {
			return;
		}

		if (isBusy) {
			if (!bulkCompleteBtn.dataset.originalText) {
				bulkCompleteBtn.dataset.originalText = bulkCompleteBtn.textContent;
			}

			bulkCompleteBtn.disabled = true;
			bulkCompleteBtn.textContent = "처리중";
		} else {
			bulkCompleteBtn.textContent = bulkCompleteBtn.dataset.originalText || "체크완료";
			updateBulkModalButtons();
		}

		if (bulkCheckAllBtn) {
			bulkCheckAllBtn.disabled = isBusy || getBulkPendingCheckboxes().length === 0;
		}
	}

	async function completeBulkChecks() {
		const selectedOrderIds = getSelectedBulkOrderIds();

		if (selectedOrderIds.length === 0) {
			alert("체크완료 처리할 오더를 하나 이상 선택해 주세요.");
			return;
		}

		if (!confirm(selectedOrderIds.length + "건을 체크완료 처리하시겠습니까?")) {
			return;
		}

		try {
			setBulkCompleteBusy(true);

			const response = await fetch("/management/api/non-standard-task-list-second/check-complete", {
				method: "POST",
				headers: buildJsonHeaders(),
				body: JSON.stringify({ orderIds: selectedOrderIds })
			});

			let data = null;
			try {
				data = await response.json();
			} catch (e) {
				data = null;
			}

			if (!response.ok || !data || data.success !== true) {
				throw new Error(data?.message || "체크완료 처리 중 오류가 발생했습니다.");
			}

			alert(data.message || "체크완료 처리되었습니다.");
			showPageLoading("목록을 다시 불러오는 중입니다.");
			window.location.reload();
		} catch (error) {
			alert(error.message || "체크완료 처리 중 오류가 발생했습니다.");
		} finally {
			setBulkCompleteBusy(false);
		}
	}

	function refreshNewImageEmptyState(section) {
		if (!section) {
			return;
		}

		const preview = section.querySelector(".admin-task-list-second-new-image-preview");
		const empty = section.querySelector(".admin-task-list-second-new-image-empty");

		if (!preview || !empty) {
			return;
		}

		const hasImages = preview.querySelectorAll(".admin-task-list-second-new-image-card").length > 0;
		empty.style.display = hasImages ? "none" : "block";
	}

	function rebuildFileInput(input, files) {
		const dataTransfer = new DataTransfer();

		files.forEach(file => {
			dataTransfer.items.add(file);
		});

		input.files = dataTransfer.files;
	}

	function renderNewImagePreviews(input) {
		if (!input) {
			return;
		}

		const section = input.closest(".admin-task-list-second-image-section");
		const preview = section?.querySelector(".admin-task-list-second-new-image-preview");

		if (!section || !preview) {
			return;
		}

		preview.innerHTML = "";

		Array.from(input.files || []).forEach((file, index) => {
			const card = document.createElement("div");
			card.className = "admin-task-list-second-image-card admin-task-list-second-new-image-card";
			card.dataset.fileIndex = String(index);

			const removeButton = document.createElement("button");
			removeButton.type = "button";
			removeButton.className = "admin-task-list-second-image-remove-btn admin-task-list-second-new-image-remove-btn";
			removeButton.textContent = "×";
			removeButton.dataset.fileIndex = String(index);

			const img = document.createElement("img");
			img.alt = file.name;

			const reader = new FileReader();
			reader.onload = function(event) {
				img.src = event.target.result;
			};
			reader.readAsDataURL(file);

			const name = document.createElement("div");
			name.className = "admin-task-list-second-image-name";
			name.textContent = file.name;

			card.appendChild(removeButton);
			card.appendChild(img);
			card.appendChild(name);
			preview.appendChild(card);
		});

		refreshNewImageEmptyState(section);
	}

	function markExistingImageForDelete(button) {
		const imageId = button?.dataset?.imageId;

		if (!imageId) {
			return;
		}

		const section = button.closest(".admin-task-list-second-image-section");
		const card = button.closest(".admin-task-list-second-existing-image-card");
		const holder = section?.querySelector(".admin-task-list-second-delete-image-holder");

		if (!section || !card || !holder) {
			return;
		}

		const existingHidden = holder.querySelector(`input[name="deleteAdminImageIds"][value="${imageId}"]`);

		if (existingHidden) {
			existingHidden.remove();
			card.classList.remove("is-delete-pending");
			button.textContent = "×";
			return;
		}

		const hidden = document.createElement("input");
		hidden.type = "hidden";
		hidden.name = "deleteAdminImageIds";
		hidden.value = imageId;

		holder.appendChild(hidden);
		card.classList.add("is-delete-pending");
		button.textContent = "↺";
	}

	function removeNewImage(button) {
		const fileIndex = Number(button?.dataset?.fileIndex);

		if (Number.isNaN(fileIndex)) {
			return;
		}

		const section = button.closest(".admin-task-list-second-image-section");
		const input = section?.querySelector(".admin-task-list-second-admin-image-input");

		if (!section || !input) {
			return;
		}

		const files = Array.from(input.files || []);
		files.splice(fileIndex, 1);

		rebuildFileInput(input, files);
		renderNewImagePreviews(input);
	}

	function initializeImageSection(root) {
		const base = root || document;
		base.querySelectorAll(".admin-task-list-second-image-section").forEach(refreshNewImageEmptyState);
	}

	function initializeBaseEvents() {
		updateDateInputs();
		highlightProductNameMatches(document);
		if (rangeToggleBtn) {
			const isRangeOpen = !rangeFields?.classList.contains("d-none");
			rangeToggleBtn.setAttribute("aria-expanded", isRangeOpen ? "true" : "false");
			rangeToggleBtn.classList.toggle("is-active", isRangeOpen);
		}

		if (filterForm) {
			filterForm.addEventListener("submit", function(event) {
				if (!validateOrderIdRange()) {
					event.preventDefault();
					event.stopImmediatePropagation();
				}
			});
		}

		if (dateCriteriaSelect) {
			dateCriteriaSelect.addEventListener("change", updateDateInputs);
		}

		dateStepButtons.forEach(button => {
			button.addEventListener("click", function() {
				submitDateStep(button.dataset.dayStep);
			});
		});

		singleDateInput?.addEventListener("change", function() {
			applySingleDate(singleDateInput.value);
		});

		rangeToggleBtn?.addEventListener("click", toggleRangeSearch);
		readonlyListOpenBtn?.addEventListener("click", openReadonlyListModal);
		readonlyListHost?.addEventListener("click", function(event) {
			const swipedSlide = event.target.closest(".admin-task-readonly-gallery-slide");
			const swipedGallery = swipedSlide?.closest("[data-readonly-gallery]");
			if (swipedGallery && Date.now() - Number(swipedGallery.dataset.lastSwipeAt || 0) < 450) {
				event.preventDefault();
				return;
			}
			const control = event.target.closest("[data-readonly-gallery-step], [data-readonly-gallery-go]");
			if (!control || !readonlyListHost.contains(control)) return;
			const gallery = control.closest("[data-readonly-gallery]");
			if (!gallery) return;
			event.preventDefault();
			if (control.hasAttribute("data-readonly-gallery-step")) {
				moveReadonlyGallery(gallery, control.dataset.readonlyGalleryStep);
				return;
			}
			updateReadonlyGallery(gallery, control.dataset.readonlyGalleryGo);
		});
		readonlyListHost?.addEventListener("keydown", function(event) {
			if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
			const gallery = event.target.closest("[data-readonly-gallery]");
			if (!gallery || !readonlyListHost.contains(gallery)) return;
			event.preventDefault();
			moveReadonlyGallery(gallery, event.key === "ArrowRight" ? 1 : -1);
		});
		readonlyListScroll?.addEventListener("scroll", function() {
			const remaining = readonlyListScroll.scrollHeight
				- readonlyListScroll.scrollTop
				- readonlyListScroll.clientHeight;
			if (remaining < 260) {
				loadReadonlyListBatch(false);
			}
		});

		if (pageSizeSelect) {
			pageSizeSelect.addEventListener("change", function() {
				const form = pageSizeSelect.closest("form");

				if (!form) {
					return;
				}

				showPageLoading("목록을 불러오는 중입니다.");
				form.submit();
			});
		}

		if (checkAllBox) {
			checkAllBox.addEventListener("change", function() {
				getOrderCheckboxes().forEach(checkbox => {
					checkbox.checked = checkAllBox.checked;
				});

				updateBulkButtons();
			});
		}

		document.addEventListener("change", function(event) {
			if (event.target.classList.contains("task-list-order-checkbox")) {
				updateBulkButtons();
			}

			if (event.target.classList.contains("admin-task-list-second-bulk-checkbox")) {
				updateBulkModalButtons();
			}

			if (event.target.classList.contains("admin-task-list-second-admin-image-input")) {
				renderNewImagePreviews(event.target);
			}
		});

		document.addEventListener("submit", function(event) {
			if (event.target.matches(".admin-task-list-second-update-form")) {
				showPageLoading("처리 중입니다. 잠시만 기다려 주세요.");
			}
		});

		document.querySelectorAll("form:not(.admin-task-list-second-update-form)").forEach(form => {
			form.addEventListener("submit", function() {
				showPageLoading("처리 중입니다. 잠시만 기다려 주세요.");
			});
		});

		document.querySelectorAll(".pagination a").forEach(link => {
			link.addEventListener("click", function() {
				showPageLoading("목록을 불러오는 중입니다.");
			});
		});

		document.querySelectorAll(".task-list-added-sort-link").forEach(link => {
			link.addEventListener("click", function(event) {
				event.preventDefault();
				applySortLink(link);
			});
		});

		if (sortResetBtn) {
			sortResetBtn.addEventListener("click", resetSortOnly);
		}

		if (searchResetBtn) {
			searchResetBtn.addEventListener("click", resetSearchOnly);
		}

		if (deleteTasksBtn) {
			deleteTasksBtn.addEventListener("click", function() {
				callDeleteApi(
					"/management/api/non-standard-task/delete-tasks",
					"선택한 주문이 속한 태스크 전체가 삭제됩니다.\n\n해당 태스크의 모든 주문, 주문항목, 주문이미지, 배송순서 인덱스까지 함께 삭제됩니다.\n\n계속 진행하시겠습니까?"
				);
			});
		}

		if (deleteOrdersBtn) {
			deleteOrdersBtn.addEventListener("click", function() {
				callDeleteApi(
					"/management/api/non-standard-task/delete-orders",
					"선택한 주문만 삭제됩니다.\n\n삭제 후 태스크에 남은 주문이 하나도 없으면 태스크도 자동 삭제됩니다.\n\n계속 진행하시겠습니까?"
				);
			});
		}

		if (bulkConfirmBtn) {
			bulkConfirmBtn.addEventListener("click", bulkConfirmSelectedOrders);
		}

		if (bulkConfirmModalOverlay) {
			bulkConfirmModalOverlay.addEventListener("click", closeBulkConfirmModal);
		}

		if (bulkConfirmModalCloseBtn) {
			bulkConfirmModalCloseBtn.addEventListener("click", closeBulkConfirmModal);
		}

		if (bulkConfirmModalCancelBtn) {
			bulkConfirmModalCancelBtn.addEventListener("click", closeBulkConfirmModal);
		}

		if (bulkConfirmModalSubmitBtn) {
			bulkConfirmModalSubmitBtn.addEventListener("click", submitBulkConfirmModal);
		}

		document.addEventListener("keydown", function(event) {
			if (event.key === "Escape"
					&& bulkConfirmModal
					&& !bulkConfirmModal.classList.contains("d-none")) {
				closeBulkConfirmModal();
			}
		});

		if (siteStatementBtn) {
			siteStatementBtn.addEventListener("click", function() {
				downloadDeliveryStatement("SITE", siteStatementBtn);
			});
		}

		if (parcelStatementBtn) {
			parcelStatementBtn.addEventListener("click", function() {
				downloadDeliveryStatement("PARCEL", parcelStatementBtn);
			});
		}

		document.addEventListener("click", function(event) {
			const historyToggleButton = event.target.closest(".admin-task-list-second-history-toggle-btn");

			if (historyToggleButton) {
				event.preventDefault();
				toggleOrderHistory(historyToggleButton);
				return;
			}

			const toggleButton = event.target.closest(".admin-task-list-second-wide-toggle-btn");

			if (toggleButton) {
				event.preventDefault();
				toggleDetailRow(toggleButton.dataset.orderId);
				return;
			}

			const closeButton = event.target.closest(".admin-task-list-second-wide-close-btn");

			if (closeButton) {
				event.preventDefault();
				toggleDetailRow(closeButton.dataset.orderId, false);
				return;
			}

			const existingRemoveButton = event.target.closest(".admin-task-list-second-existing-image-remove-btn");

			if (existingRemoveButton) {
				event.preventDefault();
				markExistingImageForDelete(existingRemoveButton);
				return;
			}

			const newRemoveButton = event.target.closest(".admin-task-list-second-new-image-remove-btn");

			if (newRemoveButton) {
				event.preventDefault();
				removeNewImage(newRemoveButton);
			}
		});

		updateBulkButtons();
	}

	function initializeBulkModalEvents() {
		if (bulkOpenBtn) {
			bulkOpenBtn.addEventListener("click", openBulkModal);
		}

		if (bulkOverlay) {
			bulkOverlay.addEventListener("click", closeBulkModal);
		}

		if (bulkCloseBtn) {
			bulkCloseBtn.addEventListener("click", closeBulkModal);
		}

		if (bulkCheckAllBtn) {
			bulkCheckAllBtn.addEventListener("click", toggleBulkAllCheck);
		}

		if (bulkCompleteBtn) {
			bulkCompleteBtn.addEventListener("click", completeBulkChecks);
		}

		document.addEventListener("keydown", function(event) {
			if (event.key === "Escape" && bulkModal?.classList.contains("is-open")) {
				closeBulkModal();
			}
		});

		updateBulkModalButtons();
	}

	window.AdminTaskListSecond = {
		initializeImageSection,
		showPageLoading,
		hidePageLoading,
		toggleDetailRow
	};

	initializeBaseEvents();
	initializeImageSection(document);
	initializeBulkModalEvents();
});
