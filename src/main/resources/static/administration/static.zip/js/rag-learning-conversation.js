let learningConversationSessionId = null;
let learningSelectedFiles = [];
let learningActiveJobTimer = null;
let learningActiveJobId = null;

const LEARNING_CONVERSATION_API = '/admin/rag/api/learning-conversation';
const RAG_LEARNING_JS_VERSION = '20260612-eventual-ai-reparse-v1';

const LEARNING_JOB_DONE = new Set(['COMPLETED', 'FAILED', 'CANCELED']);

function learningJobApiBase() {
    return `${LEARNING_CONVERSATION_API}/${learningConversationSessionId}/jobs`;
}

document.addEventListener('DOMContentLoaded', () => {
    console.info('[RAG_LEARNING_CONVERSATION_JS] loaded', RAG_LEARNING_JS_VERSION);
    const badge = document.getElementById('learningJsVersionBadge');
    if (badge) badge.textContent = RAG_LEARNING_JS_VERSION;
    bindLearningConversationEvents();
});

function bindLearningConversationEvents() {
    document.getElementById('learningConversationStartBtn')?.addEventListener('click', startLearningConversation);
    document.getElementById('learningConversationForm')?.addEventListener('submit', sendLearningConversationMessage);
    document.getElementById('learningConversationFile')?.addEventListener('change', (e) => addLearningFiles(e.target.files));
    document.getElementById('clearLearningFilesBtn')?.addEventListener('click', clearLearningFiles);
    document.getElementById('resetKnowledgeBtn')?.addEventListener('click', resetLearningKnowledge);
    document.getElementById('retryRawKnowledgeNodesBtn')?.addEventListener('click', retryRawKnowledgeNodes);

    const dropZone = document.getElementById('learningDropZone');
    if (dropZone) bindDropZone(dropZone, addLearningFiles);

    const textarea = document.getElementById('learningConversationMessage');
    const form = document.getElementById('learningConversationForm');
    Rag.bindEnterSubmit(textarea, form);
}

function bindDropZone(zone, onFiles) {
    ['dragenter', 'dragover'].forEach(evt => zone.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        zone.classList.add('dragover');
    }));
    ['dragleave', 'drop'].forEach(evt => zone.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        zone.classList.remove('dragover');
    }));
    zone.addEventListener('drop', (e) => onFiles(e.dataTransfer.files));
    zone.addEventListener('click', () => document.getElementById('learningConversationFile')?.click());
}

function addLearningFiles(fileList) {
    const files = Array.from(fileList || []).filter(f => f && f.size > 0);
    for (const file of files) {
        const key = `${file.name}_${file.size}_${file.lastModified}`;
        if (!learningSelectedFiles.some(f => `${f.name}_${f.size}_${f.lastModified}` === key)) learningSelectedFiles.push(file);
    }
    renderLearningSelectedFiles();
}

function clearLearningFiles() {
    learningSelectedFiles = [];
    const input = document.getElementById('learningConversationFile');
    if (input) input.value = '';
    renderLearningSelectedFiles();
}

function removeLearningFile(index) {
    learningSelectedFiles.splice(index, 1);
    renderLearningSelectedFiles();
}

function renderLearningSelectedFiles() {
    const list = document.getElementById('learningSelectedFileList');
    if (!list) return;
    if (learningSelectedFiles.length === 0) {
        list.innerHTML = '<span class="text-muted small">선택된 파일 없음</span>';
        return;
    }
    list.innerHTML = learningSelectedFiles.map((f, i) => `
        <span class="rag-file-chip">
            ${Rag.escapeHtml(f.name)} <small>${Math.ceil(f.size / 1024)}KB</small>
            <button type="button" onclick="removeLearningFile(${i})" aria-label="파일 제거">×</button>
        </span>
    `).join('');
}

async function startLearningConversation() {
    stopLearningJobPolling();
    const projectId = resolveLearningProjectId();
    const versionId = resolveLearningVersionId();
    const title = document.getElementById('learningTitleInput')?.value?.trim() || '대화형 지식 학습';
    const topic = document.getElementById('learningTopicInput')?.value?.trim() || title;
    if (!projectId) {
        Rag.toast('프로젝트를 먼저 선택해 주세요.', 'warning');
        return;
    }
    try {
        const data = await Rag.jsonFetch(`${LEARNING_CONVERSATION_API}/start`, {
            method: 'POST',
            body: JSON.stringify({ projectId, versionId, title, topic })
        });
        learningConversationSessionId = data.sessionId || data.session?.id;
        const badge = document.getElementById('learningConversationSessionBadge');
        if (badge) badge.textContent = learningConversationSessionId || '-';
        const log = document.getElementById('learningConversationLog');
        if (log) log.innerHTML = '';
        Rag.appendMessage('#learningConversationLog', 'assistant', data.answer || '대화형 학습을 시작했습니다.');
        updateLearningSaveBadge('지식 저장: 대기', 'NONE');
        resetLearningJobProgress();
    } catch (e) {
        Rag.toast(e.message, 'danger');
    }
}

async function sendLearningConversationMessage(e) {
    e.preventDefault();
    if (!learningConversationSessionId) {
        await startLearningConversation();
        if (!learningConversationSessionId) return;
    }
    const textarea = document.getElementById('learningConversationMessage');
    const message = textarea?.value?.trim() || '';
    const forceSave = !!document.getElementById('learningForceSave')?.checked;
    const files = learningSelectedFiles.slice();
    if (!message && files.length === 0) return;

    if (message) Rag.appendMessage('#learningConversationLog', 'user', message);
    for (const f of files) Rag.appendMessage('#learningConversationLog', 'user', `[파일 업로드] ${f.name}`);

    resetLearningJobProgress();
    updateLearningSaveBadge('학습 작업: 접수 준비', 'RUNNING');
    setLearningConversationBusy(true);
    try {
        let data;
        if (files.length > 0) {
            const fd = new FormData();
            fd.append('message', message);
            fd.append('forceSave', String(forceSave));
            files.forEach(file => fd.append('files', file));
            data = await Rag.jsonFetch(`${LEARNING_CONVERSATION_API}/${learningConversationSessionId}/message-with-files`, {
                method: 'POST',
                body: fd
            });
            clearLearningFiles();
        } else {
            data = await Rag.jsonFetch(`${LEARNING_CONVERSATION_API}/${learningConversationSessionId}/message`, {
                method: 'POST',
                body: JSON.stringify({ message, forceSave })
            });
        }
        if (textarea) textarea.value = '';
        if (data.accepted && data.jobId) {
            Rag.appendMessage('#learningConversationLog', 'system', data.answer || '학습 작업을 접수했습니다.');
            renderLearningJobProgress(data);
            startLearningJobPolling(data.jobId);
        } else {
            Rag.appendMessage('#learningConversationLog', data.requiresClarification ? 'system' : 'assistant', data.answer || '분석 결과를 생성하지 못했습니다.');
            renderLearningSaveStatus(data);
            renderLearningConversationResult(data);
            setLearningConversationBusy(false);
            textarea?.focus();
        }
    } catch (err) {
        Rag.toast(err.message, 'danger');
        Rag.appendMessage('#learningConversationLog', 'system', err.message);
        setLearningConversationBusy(false);
        textarea?.focus();
    }
}

function startLearningJobPolling(jobId) {
    stopLearningJobPolling();
    learningActiveJobId = jobId;
    pollLearningJob(jobId);
    learningActiveJobTimer = window.setInterval(() => pollLearningJob(jobId), 1500);
}

function stopLearningJobPolling() {
    if (learningActiveJobTimer) window.clearInterval(learningActiveJobTimer);
    learningActiveJobTimer = null;
    learningActiveJobId = null;
}

async function pollLearningJob(jobId) {
    if (!learningConversationSessionId || !jobId) return;
    try {
        const job = await Rag.jsonFetch(`${learningJobApiBase()}/${jobId}`);
        renderLearningJobProgress(job);
        const runStatus = String(job.runStatus || job.run_status || '').toUpperCase();
        const status = String(job.status || '').toUpperCase();
        if (LEARNING_JOB_DONE.has(runStatus) || LEARNING_JOB_DONE.has(status)) {
            stopLearningJobPolling();
            setLearningConversationBusy(false);
            const textarea = document.getElementById('learningConversationMessage');
            textarea?.focus();
            if (runStatus === 'FAILED' || status === 'FAILED') {
                const msg = job.error_message || job.errorMessage || job.statusMessage || '학습 작업이 실패했습니다.';
                Rag.appendMessage('#learningConversationLog', 'system', `[학습 실패] ${msg}`);
                updateLearningSaveBadge('지식 저장: 실패', 'RESET');
                renderLearningConversationResult(job.result && Object.keys(job.result).length ? job.result : job);
                return;
            }
            const finalResult = job.result && Object.keys(job.result).length ? job.result : job;
            if (!finalResult.answer && job.answer) finalResult.answer = job.answer;
            Rag.appendMessage('#learningConversationLog', finalResult.requiresClarification ? 'system' : 'assistant', finalResult.answer || '학습 작업이 완료되었습니다.');
            renderLearningSaveStatus(finalResult);
            renderLearningConversationResult(finalResult);
        }
    } catch (e) {
        stopLearningJobPolling();
        setLearningConversationBusy(false);
        Rag.toast(e.message, 'danger');
        Rag.appendMessage('#learningConversationLog', 'system', e.message);
    }
}

function renderLearningJobProgress(job) {
    const status = job.status || '-';
    const runStatus = job.runStatus || job.run_status || 'RUNNING';
    const progress = Number(job.progress || 0);
    const msg = job.statusMessage || job.status_message || '';
    const statusEl = document.getElementById('learningJobStatusText');
    const progressBar = document.getElementById('learningJobProgressBar');
    const logEl = document.getElementById('learningJobLogList');
    const jobIdEl = document.getElementById('learningActiveJobId');
    if (jobIdEl) jobIdEl.textContent = job.jobId || job.id || '-';
    if (statusEl) statusEl.textContent = `${runStatus} / ${status} / ${progress}%${msg ? ' - ' + msg : ''}`;
    if (progressBar) {
        progressBar.style.width = `${Math.max(0, Math.min(100, progress))}%`;
        progressBar.textContent = `${Math.max(0, Math.min(100, progress))}%`;
    }
    if (logEl && Array.isArray(job.logs)) {
        logEl.innerHTML = job.logs.map(log => `
            <div class="rag-job-log-row">
                <span class="badge text-bg-light border">${Rag.escapeHtml(log.status || '')}</span>
                <span>${Rag.escapeHtml(String(log.progress ?? ''))}%</span>
                <span>${Rag.escapeHtml(log.message || '')}</span>
            </div>
        `).join('');
        logEl.scrollTop = logEl.scrollHeight;
    }
    updateLearningSaveBadge(`학습 작업: ${status}`, runStatus === 'FAILED' ? 'RESET' : 'RUNNING');
}

function resetLearningJobProgress() {
    const statusEl = document.getElementById('learningJobStatusText');
    const progressBar = document.getElementById('learningJobProgressBar');
    const logEl = document.getElementById('learningJobLogList');
    const jobIdEl = document.getElementById('learningActiveJobId');
    if (jobIdEl) jobIdEl.textContent = '-';
    if (statusEl) statusEl.textContent = '대기';
    if (progressBar) {
        progressBar.style.width = '0%';
        progressBar.textContent = '0%';
    }
    if (logEl) logEl.innerHTML = '<div class="text-muted small">아직 진행 로그가 없습니다.</div>';
}

async function retryRawKnowledgeNodes() {
    if (!learningConversationSessionId) {
        Rag.toast('먼저 학습 세션을 시작해 주세요.', 'warning');
        return;
    }
    stopLearningJobPolling();
    resetLearningJobProgress();
    updateLearningSaveBadge('재해석 작업: 접수 준비', 'RUNNING');
    setLearningConversationBusy(true);
    try {
        const limit = Number(document.getElementById('retryRawNodeLimit')?.value || 20);
        const data = await Rag.jsonFetch(`${LEARNING_CONVERSATION_API}/${learningConversationSessionId}/retry-raw-nodes?limit=${encodeURIComponent(limit)}`, {
            method: 'POST'
        });
        if (data.accepted && data.jobId) {
            Rag.appendMessage('#learningConversationLog', 'system', data.answer || '재해석 작업을 접수했습니다.');
            renderLearningJobProgress(data);
            startLearningJobPolling(data.jobId);
        } else {
            Rag.appendMessage('#learningConversationLog', 'system', data.message || data.answer || '재해석 작업 결과를 받았습니다.');
            renderLearningConversationResult(data);
            setLearningConversationBusy(false);
        }
    } catch (e) {
        Rag.toast(e.message, 'danger');
        Rag.appendMessage('#learningConversationLog', 'system', e.message);
        setLearningConversationBusy(false);
    }
}

async function resetLearningKnowledge() {
    if (!learningConversationSessionId) {
        Rag.toast('먼저 학습 세션을 시작해 주세요.', 'warning');
        return;
    }
    const topic = document.getElementById('learningTopicInput')?.value?.trim() || '';
    const reason = document.getElementById('resetKnowledgeReason')?.value?.trim() || '학습 주제 초기화';
    const resetWholeVersion = !!document.getElementById('resetWholeVersion')?.checked;
    const message = resetWholeVersion
        ? '현재 버전 전체 학습 지식을 초기화합니다. 계속 진행하시겠습니까?'
        : `현재 주제${topic ? `(${topic})` : ''}의 학습 지식을 초기화합니다. 계속 진행하시겠습니까?`;
    if (!confirm(message)) return;

    try {
        stopLearningJobPolling();
        const data = await Rag.jsonFetch(`${LEARNING_CONVERSATION_API}/${learningConversationSessionId}/reset-knowledge`, {
            method: 'POST',
            body: JSON.stringify({ topic, reason, resetWholeVersion })
        });
        Rag.appendMessage('#learningConversationLog', 'system', data.answer || '초기화되었습니다.');
        Rag.appendMessage('#learningConversationLog', 'system', '초기화 범위의 기존 학습 세션도 정리되었으므로, 계속 학습하려면 [대화형 학습 시작]을 다시 눌러 주세요.');
        learningConversationSessionId = null;
        const badge = document.getElementById('learningConversationSessionBadge');
        if (badge) badge.textContent = '-';
        updateLearningSaveBadge(data.saveStatus || '지식 저장: 초기화', 'RESET');
        renderLearningConversationResult(data);
        resetLearningJobProgress();
    } catch (e) {
        Rag.toast(e.message, 'danger');
    }
}

function renderLearningConversationResult(data) {
    const analysisBox = document.getElementById('learningConversationAnalysisBox');
    const versionBox = document.getElementById('learningConversationVersionBox');
    const retrievedBox = document.getElementById('learningConversationRetrievedBox');
    const structuredBox = document.getElementById('learningConversationStructuredBox');
    if (analysisBox) {
        const title = data.requiresClarification ? '[저장 보류 - 확인 필요]\n' : (data.shouldPersist ? '[저장 완료]\n' : '[저장 생략/응답 전용]\n');
        analysisBox.textContent = title + Rag.pretty(data.analysis || data.resetResult || data.result || data || {});
    }
    if (versionBox) versionBox.textContent = Rag.pretty(data.version || {});
    if (retrievedBox) retrievedBox.textContent = Rag.pretty(data.retrieved || []);
    if (structuredBox) structuredBox.textContent = Rag.pretty({ preprocess: data.preprocess || null, structuredResults: data.structuredResults || [], structuredReset: data.structuredReset || null });
}

function setLearningConversationBusy(busy) {
    const btn = document.querySelector('#learningConversationForm button[type="submit"]');
    const textarea = document.getElementById('learningConversationMessage');
    const startBtn = document.getElementById('learningConversationStartBtn');
    if (btn) {
        btn.disabled = busy;
        btn.textContent = busy ? '진행 중...' : '분석/저장';
    }
    if (textarea) textarea.disabled = busy;
    if (startBtn) startBtn.disabled = busy;
}

function resolveLearningProjectId() {
    const direct = document.getElementById('learningProjectId')?.value;
    if (direct) return direct;
    const select = document.getElementById('projectSelect') || document.getElementById('learningProjectSelect') || document.getElementById('chatProjectSelect');
    return Rag.selectedOption(select);
}

function resolveLearningVersionId() {
    const direct = document.getElementById('learningVersionId')?.value;
    if (direct) return direct;
    const select = document.getElementById('versionSelect') || document.getElementById('learningVersionSelect');
    return Rag.selectedOption(select);
}

function renderLearningSaveStatus(data) {
    const label = data.saveStatus || (data.memory && data.memory.saveLabel) || '지식 저장: 저장 생략';
    let status = data.memory?.status || 'NO_KNOWLEDGE_CHANGE';
    if (label.includes('저장됨')) status = 'PERSISTED';
    else if (label.includes('보류')) status = 'WAITING_USER';
    else if (label.includes('초기화')) status = 'RESET';
    const message = data.saveMessage || data.memory?.message || '대화 로그는 저장되었지만 재사용 가능한 새 지식이 아니어서 지식 저장은 생략했습니다.';
    updateLearningSaveBadge(label, status);
    Rag.appendMessage('#learningConversationLog', status === 'WAITING_USER' ? 'system' : 'save', `[${label}] ${message}`);
}

function updateLearningSaveBadge(label, status) {
    const badge = document.getElementById('learningSaveStatusBadge');
    if (!badge) return;
    badge.textContent = label || '-';
    if (status === 'PERSISTED') badge.className = 'badge text-bg-success fs-6';
    else if (status === 'WAITING_USER') badge.className = 'badge text-bg-warning fs-6';
    else if (status === 'RESET') badge.className = 'badge text-bg-danger fs-6';
    else if (status === 'RUNNING') badge.className = 'badge text-bg-info fs-6';
    else if (status === 'NO_KNOWLEDGE_CHANGE') badge.className = 'badge text-bg-secondary fs-6';
    else badge.className = 'badge text-bg-info fs-6';
}
